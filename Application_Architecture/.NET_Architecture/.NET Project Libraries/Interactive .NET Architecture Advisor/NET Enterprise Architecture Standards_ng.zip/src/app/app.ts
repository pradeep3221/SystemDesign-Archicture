import { Component, signal, computed, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { SECTION_REGISTRY } from './data/section-registry';
import { StandardsDataService } from './services/standards-data.service';

@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet, RouterLink, RouterLinkActive,
    MatToolbarModule, MatSidenavModule, MatListModule,
    MatIconModule, MatButtonModule, MatFormFieldModule,
    MatInputModule, MatAutocompleteModule, FormsModule, SlicePipe
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  private readonly dataService = inject(StandardsDataService);

  // Navigation is driven by the section registry — single source of truth.
  protected readonly navSections = SECTION_REGISTRY.map(e => e.nav);
  protected readonly sidenavOpened = signal(true);

  // Global search
  protected readonly searchQuery = this.dataService.searchQuery;
  protected readonly searchResults = this.dataService.searchResults;

  toggleSidenav() {
    this.sidenavOpened.update(v => !v);
  }
}
