import { Component, input } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'app-copy-clipboard',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatSnackBarModule],
  template: `
    <button mat-icon-button (click)="copy()" aria-label="Copy to clipboard" class="copy-btn">
      <mat-icon>content_copy</mat-icon>
    </button>
  `,
  styles: `
    .copy-btn {
      opacity: 0.6;
      transition: opacity 0.2s;
    }
    .copy-btn:hover {
      opacity: 1;
    }
  `
})
export class CopyClipboard {
  text = input.required<string>();

  constructor(private snackBar: MatSnackBar) {}

  copy() {
    navigator.clipboard.writeText(this.text()).then(() => {
      this.snackBar.open('Copied to clipboard!', '', { duration: 2000 });
    });
  }
}
