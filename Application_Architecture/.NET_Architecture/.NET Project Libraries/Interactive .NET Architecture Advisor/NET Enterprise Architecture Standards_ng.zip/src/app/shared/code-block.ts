import { Component, input } from '@angular/core';
import { CopyClipboard } from './copy-clipboard';

@Component({
  selector: 'app-code-block',
  standalone: true,
  imports: [CopyClipboard],
  template: `
    <div class="code-block">
      <div class="code-header">
        @if (title()) {
          <span class="code-title">{{ title() }}</span>
        }
        <app-copy-clipboard [text]="code()" />
      </div>
      <pre><code>{{ code() }}</code></pre>
    </div>
  `,
  styles: `
    .code-block {
      background: #1e1e1e;
      border-radius: 8px;
      overflow: hidden;
      margin: 16px 0;
    }
    .code-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 16px;
      background: #2d2d2d;
      border-bottom: 1px solid #444;
    }
    .code-title {
      color: #9cdcfe;
      font-size: 13px;
      font-weight: 500;
    }
    pre {
      margin: 0;
      padding: 16px;
      overflow-x: auto;
      font-family: 'Cascadia Code', 'Fira Code', 'Consolas', monospace;
      font-size: 13px;
      line-height: 1.5;
    }
    code {
      color: #d4d4d4;
    }
  `
})
export class CodeBlock {
  code = input.required<string>();
  title = input<string>('');
}
