import { Component, input } from '@angular/core';

@Component({
  selector: 'app-enforcement-badge',
  standalone: true,
  template: `
    <span class="badge" [class]="'badge-' + level()">
      {{ icon() }} {{ level() }}
    </span>
  `,
  styles: `
    .badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
      white-space: nowrap;
    }
    .badge-MUST {
      background: #fde8e8;
      color: #c62828;
    }
    .badge-SHOULD {
      background: #fff3e0;
      color: #e65100;
    }
    .badge-MAY {
      background: #e8f5e9;
      color: #2e7d32;
    }
    .badge-MUST-NOT {
      background: #f3e5f5;
      color: #6a1b9a;
    }
  `
})
export class EnforcementBadge {
  level = input.required<string>();

  icon = input<string>('');
}
