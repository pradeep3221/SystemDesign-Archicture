import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'enforcementIcon', standalone: true })
export class EnforcementIconPipe implements PipeTransform {
  transform(value: string): string {
    switch (value) {
      case 'MUST': return '🔒';
      case 'SHOULD': return '📋';
      case 'MAY': return '💡';
      default: return '';
    }
  }
}
