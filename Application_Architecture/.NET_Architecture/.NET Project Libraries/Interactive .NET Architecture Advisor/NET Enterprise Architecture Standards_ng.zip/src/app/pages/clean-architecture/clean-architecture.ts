import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { DEPENDENCY_RULES } from '../../data/standards-data';

@Component({
  selector: 'app-clean-architecture',
  standalone: true,
  imports: [MatCardModule, MatListModule],
  template: `
    <h2 class="page-title">5. Clean Architecture — Layer Dependencies</h2>

    <mat-card class="rules-card">
      <mat-card-content>
        <mat-list>
          @for (rule of dependencyRules; track rule.rule) {
            <mat-list-item class="rule-item">
              <div class="rule-content">
                <strong>{{ rule.rule }}</strong>
                <p class="rule-desc">{{ rule.description }}</p>
              </div>
            </mat-list-item>
          }
        </mat-list>
      </mat-card-content>
    </mat-card>

    <h3 class="section-title">Dependency Diagram</h3>
    <div class="diagram-wrapper">
      <div class="layer presentation">
        <span class="layer-label">Presentation</span>
        <span class="arrow">depends on ↓</span>
        <div class="layer infrastructure">
          <span class="layer-label">Infrastructure</span>
          <span class="arrow">depends on ↓</span>
          <div class="layer application">
            <span class="layer-label">Application</span>
            <span class="arrow">depends on ↓</span>
            <div class="layer domain">
              <span class="layer-label">Domain</span>
              <span class="core-note">No dependencies</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-title {
      margin-top: 32px;
      margin-bottom: 16px;
    }
    .rules-card {
      margin-bottom: 24px;
    }
    .rule-item {
      height: auto !important;
      padding: 8px 0;
    }
    .rule-content {
      padding: 4px 0;
    }
    .rule-desc {
      margin: 4px 0 0;
      color: rgba(0, 0, 0, 0.6);
      font-size: 14px;
      line-height: 1.4;
    }
    .diagram-wrapper {
      display: flex;
      justify-content: center;
      padding: 24px 0;
    }
    .layer {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      padding: 20px 28px;
      border-radius: 12px;
      position: relative;
    }
    .layer-label {
      font-weight: 700;
      font-size: 15px;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }
    .arrow {
      font-size: 12px;
      opacity: 0.7;
      margin-bottom: 10px;
    }
    .core-note {
      font-size: 11px;
      opacity: 0.6;
      margin-top: 4px;
    }
    .presentation {
      background-color: #cfd8dc;
      color: #37474f;
      min-width: 400px;
    }
    .infrastructure {
      background-color: #ffe082;
      color: #6d4c00;
      min-width: 310px;
    }
    .application {
      background-color: #b3e5fc;
      color: #01579b;
      min-width: 230px;
    }
    .domain {
      background-color: #a5d6a7;
      color: #1b5e20;
      min-width: 150px;
      min-height: 60px;
      justify-content: center;
    }
  `]
})
export class CleanArchitecturePage {
  readonly dependencyRules = DEPENDENCY_RULES;
}
