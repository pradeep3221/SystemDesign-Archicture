import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import { EnforcementIconPipe } from '../../shared/enforcement-icon.pipe';
import { CodeBlock } from '../../shared/code-block';
import {
  FOLDER_STRUCTURE,
  NAMING_CONVENTIONS,
  DEPENDENCY_RULES,
} from '../../data/standards-data';

@Component({
  selector: 'app-folder-structure',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    EnforcementBadge,
    EnforcementIconPipe,
    CodeBlock,
  ],
  template: `
    <h2 class="page-title">12. Solution &amp; Folder Structure Standard</h2>

    <mat-card class="section-card">
      <mat-card-header>
        <mat-card-title>Standard Layout</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <app-code-block [code]="folderStructure" title="Solution Folder Structure" />
      </mat-card-content>
    </mat-card>

    <mat-card class="section-card">
      <mat-card-header>
        <mat-card-title>Naming Conventions</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="namingConventions" class="full-width">
          <ng-container matColumnDef="element">
            <th mat-header-cell *matHeaderCellDef>Element</th>
            <td mat-cell *matCellDef="let row">{{ row.element }}</td>
          </ng-container>

          <ng-container matColumnDef="convention">
            <th mat-header-cell *matHeaderCellDef>Convention</th>
            <td mat-cell *matCellDef="let row">{{ row.convention }}</td>
          </ng-container>

          <ng-container matColumnDef="example">
            <th mat-header-cell *matHeaderCellDef>Example</th>
            <td mat-cell *matCellDef="let row">
              <code>{{ row.example }}</code>
            </td>
          </ng-container>

          <ng-container matColumnDef="enforcement">
            <th mat-header-cell *matHeaderCellDef>Enforcement</th>
            <td mat-cell *matCellDef="let row">
              <app-enforcement-badge
                [level]="row.enforcement"
                [icon]="row.enforcement | enforcementIcon"
              />
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="namingColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: namingColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>

    <mat-card class="section-card">
      <mat-card-header>
        <mat-card-title>Dependency Rules</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="dependencyRules" class="full-width">
          <ng-container matColumnDef="rule">
            <th mat-header-cell *matHeaderCellDef>Rule</th>
            <td mat-cell *matCellDef="let row">{{ row.rule }}</td>
          </ng-container>

          <ng-container matColumnDef="description">
            <th mat-header-cell *matHeaderCellDef>Description</th>
            <td mat-cell *matCellDef="let row">{{ row.description }}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="depColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: depColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-card {
      margin-bottom: 24px;
    }
    .full-width {
      width: 100%;
    }
    code {
      background: #f5f5f5;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 13px;
    }
  `],
})
export class FolderStructurePage {
  readonly folderStructure = FOLDER_STRUCTURE;
  readonly namingConventions = NAMING_CONVENTIONS;
  readonly dependencyRules = DEPENDENCY_RULES;

  readonly namingColumns = ['element', 'convention', 'example', 'enforcement'];
  readonly depColumns = ['rule', 'description'];
}
