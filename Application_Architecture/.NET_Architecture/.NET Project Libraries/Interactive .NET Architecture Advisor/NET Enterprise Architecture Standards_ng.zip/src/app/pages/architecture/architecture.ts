import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { PROJECT_TYPES } from '../../data/standards-data';

@Component({
  selector: 'app-architecture',
  standalone: true,
  imports: [MatCardModule, MatTableModule],
  template: `
    <h2 class="page-title">2. Architecture Patterns &amp; Selection Guide</h2>

    <mat-card class="intro-card">
      <mat-card-content>
        <p>
          Choosing the right architecture pattern is critical for long-term maintainability and scalability.
          Each project type maps to a recommended architecture based on complexity, team size, and domain requirements.
          Use the table below to identify the correct pattern for your project, then refer to the Clean Architecture
          layer diagram for dependency guidance.
        </p>
      </mat-card-content>
    </mat-card>

    <mat-card>
      <mat-card-content>
        <table mat-table [dataSource]="dataSource" class="full-width">
          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Project Type</th>
            <td mat-cell *matCellDef="let row">{{ row.name }}</td>
          </ng-container>

          <ng-container matColumnDef="architecture">
            <th mat-header-cell *matHeaderCellDef>Architecture</th>
            <td mat-cell *matCellDef="let row">{{ row.architecture }}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>

    <h3 class="section-title">Clean Architecture Layers</h3>
    <div class="layer-diagram">
      <div class="layer presentation">
        <span class="layer-label">Presentation</span>
        <div class="layer infrastructure">
          <span class="layer-label">Infrastructure</span>
          <div class="layer application">
            <span class="layer-label">Application</span>
            <div class="layer domain">
              <span class="layer-label">Domain</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-title {
      margin-top: 32px;
      margin-bottom: 16px;
    }
    .intro-card {
      margin-bottom: 24px;
    }
    .full-width {
      width: 100%;
    }
    mat-card {
      margin-bottom: 24px;
    }
    .layer-diagram {
      display: flex;
      justify-content: center;
      padding: 24px 0;
    }
    .layer {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      border-radius: 12px;
      padding: 24px;
      position: relative;
    }
    .layer-label {
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 12px;
      letter-spacing: 0.5px;
    }
    .presentation {
      background-color: #cfd8dc;
      color: #37474f;
      min-width: 420px;
      min-height: 380px;
    }
    .infrastructure {
      background-color: #ffe082;
      color: #6d4c00;
      min-width: 320px;
      min-height: 280px;
    }
    .application {
      background-color: #b3e5fc;
      color: #01579b;
      min-width: 220px;
      min-height: 180px;
    }
    .domain {
      background-color: #a5d6a7;
      color: #1b5e20;
      min-width: 130px;
      min-height: 80px;
    }
  `]
})
export class ArchitecturePage {
  readonly dataSource = PROJECT_TYPES;
  readonly displayedColumns = ['name', 'architecture'];
}
