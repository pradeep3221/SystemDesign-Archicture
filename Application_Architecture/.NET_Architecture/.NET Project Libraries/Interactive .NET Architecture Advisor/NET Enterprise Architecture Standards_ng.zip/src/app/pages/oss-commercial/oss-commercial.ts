import { Component, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { OSS_COMMERCIAL_MATRIX, OssCommercialRow } from '../../data/standards-data';

@Component({
  selector: 'app-oss-commercial',
  standalone: true,
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatIconModule,
  ],
  template: `
    <section class="page-container">
      <h2>9. OSS vs Commercial Decision Matrix</h2>

      <mat-form-field appearance="outline" class="search-field">
        <mat-label>Search matrix...</mat-label>
        <input matInput [ngModel]="searchText()" (ngModelChange)="searchText.set($event)" placeholder="Filter rows" />
        <mat-icon matSuffix>search</mat-icon>
      </mat-form-field>

      @if (filteredRows().length === 0) {
        <p class="no-results">No rows match your search.</p>
      } @else {
        <table mat-table [dataSource]="filteredRows()" class="mat-elevation-z2 oss-table">
          <ng-container matColumnDef="category">
            <th mat-header-cell *matHeaderCellDef>Category</th>
            <td mat-cell *matCellDef="let row">{{ row.category }}</td>
          </ng-container>

          <ng-container matColumnDef="ossChoice">
            <th mat-header-cell *matHeaderCellDef class="oss-header">OSS Choice</th>
            <td mat-cell *matCellDef="let row" class="oss-cell">{{ row.ossChoice }}</td>
          </ng-container>

          <ng-container matColumnDef="commercialChoice">
            <th mat-header-cell *matHeaderCellDef class="commercial-header">Commercial Choice</th>
            <td mat-cell *matCellDef="let row" class="commercial-cell">{{ row.commercialChoice }}</td>
          </ng-container>

          <ng-container matColumnDef="chooseCommercialWhen">
            <th mat-header-cell *matHeaderCellDef>Choose Commercial When...</th>
            <td mat-cell *matCellDef="let row">{{ row.chooseCommercialWhen }}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      }
    </section>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }

    h2 {
      margin-bottom: 20px;
      font-weight: 500;
    }

    .search-field {
      width: 100%;
      max-width: 480px;
      margin-bottom: 16px;
    }

    .oss-table {
      width: 100%;
    }

    .oss-header, .oss-cell {
      background-color: #e8f5e9;
    }

    .commercial-header, .commercial-cell {
      background-color: #fff8e1;
    }

    .no-results {
      padding: 24px;
      text-align: center;
      color: rgba(0, 0, 0, 0.54);
    }

    td.mat-mdc-cell, th.mat-mdc-header-cell {
      padding: 12px 16px;
    }
  `],
})
export class OssCommercialPage {
  readonly displayedColumns = ['category', 'ossChoice', 'commercialChoice', 'chooseCommercialWhen'];
  readonly searchText = signal('');

  readonly filteredRows = computed(() => {
    const term = this.searchText().toLowerCase().trim();
    if (!term) return OSS_COMMERCIAL_MATRIX;
    return OSS_COMMERCIAL_MATRIX.filter(
      (row) =>
        row.category.toLowerCase().includes(term) ||
        row.ossChoice.toLowerCase().includes(term) ||
        row.commercialChoice.toLowerCase().includes(term) ||
        row.chooseCommercialWhen.toLowerCase().includes(term)
    );
  });
}
