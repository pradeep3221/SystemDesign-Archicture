import { Component } from '@angular/core';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { VERSIONING_RULES } from '../../data/standards-data';

@Component({
  selector: 'app-versioning',
  standalone: true,
  imports: [MatListModule, MatDividerModule],
  template: `
    <h2 class="page-title">11. Versioning Strategy</h2>

    <mat-list>
      @for (rule of rules; track rule.principle; let last = $last) {
        <mat-list-item class="rule-item">
          <span matListItemTitle class="principle">{{ rule.principle }}</span>
          <span matListItemLine class="guidance">{{ rule.guidance }}</span>
        </mat-list-item>
        @if (!last) {
          <mat-divider />
        }
      }
    </mat-list>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .rule-item {
      height: auto !important;
      padding: 12px 0;
    }
    .principle {
      font-weight: 600;
      font-size: 15px;
    }
    .guidance {
      color: rgba(0, 0, 0, 0.6);
      white-space: normal !important;
      line-height: 1.5;
    }
  `],
})
export class VersioningPage {
  readonly rules = VERSIONING_RULES;
}
