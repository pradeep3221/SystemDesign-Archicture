import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { CodeBlock } from '../../shared/code-block';
import { REFERENCE_ARCHITECTURES, ReferenceArchitecture } from '../../data/standards-data';

@Component({
  selector: 'app-reference-architectures',
  standalone: true,
  imports: [MatCardModule, CodeBlock],
  template: `
    <section class="page-container">
      <h2>8. Reference Architectures</h2>

      <div class="arch-grid">
        @for (arch of architectures; track arch.id) {
          <mat-card class="arch-card">
            <mat-card-header>
              <mat-card-title>{{ arch.title }}</mat-card-title>
            </mat-card-header>
            <mat-card-content>
              <p class="arch-description">{{ arch.description }}</p>
              <app-code-block [code]="arch.diagram" [title]="arch.title" />
            </mat-card-content>
          </mat-card>
        }
      </div>
    </section>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }

    h2 {
      margin-bottom: 20px;
      font-weight: 500;
    }

    .arch-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(600px, 1fr));
      gap: 24px;
    }

    .arch-card {
      mat-card-content {
        padding-top: 16px;
      }
    }

    .arch-description {
      margin: 0 0 16px;
      line-height: 1.6;
      color: rgba(0, 0, 0, 0.7);
    }
  `],
})
export class ReferenceArchitecturesPage {
  readonly architectures: ReferenceArchitecture[] = REFERENCE_ARCHITECTURES;
}
