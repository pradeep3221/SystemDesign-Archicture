import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import { EnforcementIconPipe } from '../../shared/enforcement-icon.pipe';
import { NFR_SECTIONS, SERVICE_TIERS } from '../../data/standards-data';

@Component({
  selector: 'app-nfr',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    MatTabsModule,
    MatIconModule,
    EnforcementBadge,
    EnforcementIconPipe,
  ],
  template: `
    <h2 class="page-title">14. Non-Functional Requirements</h2>

    <mat-card class="section-card">
      <mat-card-content>
        <mat-tab-group>
          @for (section of nfrSections; track section.id) {
            <mat-tab [label]="section.title">
              <div class="tab-content">
                <table mat-table [dataSource]="section.metrics" class="full-width">
                  <ng-container matColumnDef="metric">
                    <th mat-header-cell *matHeaderCellDef>Metric</th>
                    <td mat-cell *matCellDef="let row">{{ row.metric }}</td>
                  </ng-container>

                  <ng-container matColumnDef="target">
                    <th mat-header-cell *matHeaderCellDef>Target</th>
                    <td mat-cell *matCellDef="let row">{{ row.target }}</td>
                  </ng-container>

                  <ng-container matColumnDef="enforcement">
                    <th mat-header-cell *matHeaderCellDef>Enforcement</th>
                    <td mat-cell *matCellDef="let row">
                      <app-enforcement-badge
                        [level]="row.enforcement"
                        [icon]="row.enforcement | enforcementIcon"
                      />
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="measurement">
                    <th mat-header-cell *matHeaderCellDef>Measurement</th>
                    <td mat-cell *matCellDef="let row">{{ row.measurement }}</td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="metricColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: metricColumns"></tr>
                </table>
              </div>
            </mat-tab>
          }
        </mat-tab-group>
      </mat-card-content>
    </mat-card>

    <h3 class="section-title">Service Tier Classification</h3>

    <div class="tier-grid">
      @for (tier of serviceTiers; track tier.tier) {
        <mat-card class="tier-card">
          <mat-card-header>
            <mat-card-title>{{ tier.tier }}</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <p class="tier-definition">{{ tier.definition }}</p>
            <div class="tier-detail">
              <strong>Availability:</strong> {{ tier.availability }}
            </div>
            <div class="tier-detail">
              <strong>Performance:</strong> {{ tier.performance }}
            </div>
            <div class="tier-detail">
              <strong>Examples:</strong> {{ tier.examples }}
            </div>
          </mat-card-content>
        </mat-card>
      }
    </div>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-card {
      margin-bottom: 24px;
    }
    .tab-content {
      padding: 16px 0;
    }
    .full-width {
      width: 100%;
    }
    .section-title {
      margin: 24px 0 16px;
      font-weight: 500;
    }
    .tier-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .tier-card {
      height: 100%;
    }
    .tier-definition {
      color: rgba(0, 0, 0, 0.6);
      margin-bottom: 12px;
    }
    .tier-detail {
      margin-bottom: 6px;
      font-size: 14px;
    }
  `],
})
export class NfrPage {
  readonly nfrSections = NFR_SECTIONS;
  readonly serviceTiers = SERVICE_TIERS;

  readonly metricColumns = ['metric', 'target', 'enforcement', 'measurement'];
}
