import { Component, computed, signal } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import { EnforcementIconPipe } from '../../shared/enforcement-icon.pipe';
import { DEFAULT_STACK } from '../../data/standards-data';

@Component({
  selector: 'app-default-stack',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    EnforcementBadge,
    EnforcementIconPipe,
  ],
  template: `
    <h2 class="page-title">3. Default Technology Stack</h2>

    <mat-form-field appearance="outline" class="filter-field">
      <mat-label>Filter</mat-label>
      <mat-icon matPrefix>search</mat-icon>
      <input matInput placeholder="Search stack..." (input)="onFilter($event)" />
    </mat-form-field>

    <mat-card>
      <mat-card-content>
        <table mat-table [dataSource]="filteredData()" class="full-width">
          <ng-container matColumnDef="concern">
            <th mat-header-cell *matHeaderCellDef>Concern</th>
            <td mat-cell *matCellDef="let row">{{ row.concern }}</td>
          </ng-container>

          <ng-container matColumnDef="technology">
            <th mat-header-cell *matHeaderCellDef>Technology</th>
            <td mat-cell *matCellDef="let row">{{ row.technology }}</td>
          </ng-container>

          <ng-container matColumnDef="notes">
            <th mat-header-cell *matHeaderCellDef>Notes</th>
            <td mat-cell *matCellDef="let row">{{ row.notes }}</td>
          </ng-container>

          <ng-container matColumnDef="enforcement">
            <th mat-header-cell *matHeaderCellDef>Enforcement</th>
            <td mat-cell *matCellDef="let row">
              <app-enforcement-badge
                [level]="row.enforcement"
                [icon]="row.enforcement | enforcementIcon"
              />
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .filter-field {
      width: 100%;
      max-width: 400px;
      margin-bottom: 16px;
    }
    .full-width {
      width: 100%;
    }
    mat-card {
      margin-bottom: 24px;
    }
  `]
})
export class DefaultStackPage {
  readonly displayedColumns = ['concern', 'technology', 'notes', 'enforcement'];
  readonly filterText = signal('');

  readonly filteredData = computed(() => {
    const term = this.filterText().toLowerCase();
    if (!term) return DEFAULT_STACK;
    return DEFAULT_STACK.filter(item =>
      item.concern.toLowerCase().includes(term) ||
      item.technology.toLowerCase().includes(term) ||
      item.notes.toLowerCase().includes(term) ||
      item.enforcement.toLowerCase().includes(term)
    );
  });

  onFilter(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.filterText.set(value);
  }
}
