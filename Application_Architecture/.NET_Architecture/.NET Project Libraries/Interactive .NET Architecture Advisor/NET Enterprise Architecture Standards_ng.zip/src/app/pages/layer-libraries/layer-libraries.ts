import { Component, computed, signal } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { LAYER_LIBRARIES, SubSection, LibraryEntry } from '../../data/standards-data';

@Component({
  selector: 'app-layer-libraries',
  standalone: true,
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatTabsModule,
    MatChipsModule,
    MatIconModule,
    UpperCasePipe,
  ],
  template: `
    <section class="page-container">
      <h2>6. Layer-wise Libraries</h2>

      <mat-form-field appearance="outline" class="search-field">
        <mat-label>Search libraries...</mat-label>
        <input matInput [ngModel]="searchText()" (ngModelChange)="searchText.set($event)" placeholder="Filter across all tabs" />
        <mat-icon matSuffix>search</mat-icon>
      </mat-form-field>

      <mat-tab-group animationDuration="200ms">
        @for (section of sections; track section.id) {
          <mat-tab [label]="section.title">
            <div class="tab-content">
              @if (filteredLibraries(section).length === 0) {
                <p class="no-results">No libraries match your search.</p>
              } @else {
                <table mat-table [dataSource]="filteredLibraries(section)" class="mat-elevation-z2 lib-table">
                  <ng-container matColumnDef="concern">
                    <th mat-header-cell *matHeaderCellDef>Concern</th>
                    <td mat-cell *matCellDef="let lib">
                      {{ lib.concern }}
                      @if (lib.isNew) {
                        <span class="new-badge">🆕</span>
                      }
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="mustHave">
                    <th mat-header-cell *matHeaderCellDef>Must-Have</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.mustHave }}</td>
                  </ng-container>

                  <ng-container matColumnDef="alternatives">
                    <th mat-header-cell *matHeaderCellDef>Alternatives</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.alternatives }}</td>
                  </ng-container>

                  <ng-container matColumnDef="notes">
                    <th mat-header-cell *matHeaderCellDef>Notes</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.notes }}</td>
                  </ng-container>

                  <ng-container matColumnDef="license">
                    <th mat-header-cell *matHeaderCellDef>License</th>
                    <td mat-cell *matCellDef="let lib">
                      <mat-chip-set>
                        <mat-chip [class]="'license-' + lib.license" highlighted>
                          {{ lib.license | uppercase }}
                        </mat-chip>
                      </mat-chip-set>
                    </td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              }
            </div>
          </mat-tab>
        }
      </mat-tab-group>
    </section>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }

    h2 {
      margin-bottom: 20px;
      font-weight: 500;
    }

    .search-field {
      width: 100%;
      max-width: 480px;
      margin-bottom: 16px;
    }

    .tab-content {
      padding: 16px 0;
    }

    .lib-table {
      width: 100%;
    }

    .new-badge {
      margin-left: 6px;
      font-size: 14px;
    }

    .no-results {
      padding: 24px;
      text-align: center;
      color: rgba(0, 0, 0, 0.54);
    }

    .license-oss {
      --mdc-chip-elevated-container-color: #c8e6c9;
      --mdc-chip-label-text-color: #2e7d32;
    }

    .license-commercial {
      --mdc-chip-elevated-container-color: #ffcdd2;
      --mdc-chip-label-text-color: #c62828;
    }

    .license-mixed {
      --mdc-chip-elevated-container-color: #fff8e1;
      --mdc-chip-label-text-color: #f57f17;
    }

    td.mat-mdc-cell, th.mat-mdc-header-cell {
      padding: 12px 16px;
    }
  `],
})
export class LayerLibrariesPage {
  readonly sections = LAYER_LIBRARIES;
  readonly displayedColumns = ['concern', 'mustHave', 'alternatives', 'notes', 'license'];
  readonly searchText = signal('');

  filteredLibraries(section: SubSection): LibraryEntry[] {
    const term = this.searchText().toLowerCase().trim();
    if (!term) return section.libraries;
    return section.libraries.filter(
      (lib) =>
        lib.concern.toLowerCase().includes(term) ||
        lib.mustHave.toLowerCase().includes(term) ||
        lib.alternatives.toLowerCase().includes(term) ||
        lib.notes.toLowerCase().includes(term) ||
        lib.license.toLowerCase().includes(term)
    );
  }
}
