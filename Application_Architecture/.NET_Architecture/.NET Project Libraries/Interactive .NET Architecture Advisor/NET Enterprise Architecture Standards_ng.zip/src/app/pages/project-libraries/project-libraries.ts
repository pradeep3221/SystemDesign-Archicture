import { Component, signal } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import {
  PROJECT_SPECIFIC_LIBS,
  ASPIRE_SCENARIOS,
  ASPIRE_ANTI_PATTERNS,
  ProjectSpecificLib,
  AspireScenario,
  AspireAntiPattern,
  LibraryEntry,
} from '../../data/standards-data';

@Component({
  selector: 'app-project-libraries',
  standalone: true,
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatTabsModule,
    MatChipsModule,
    MatCardModule,
    MatIconModule,
    EnforcementBadge,
    UpperCasePipe,
  ],
  template: `
    <section class="page-container">
      <h2>7. Project-Type Specific Libraries</h2>

      <mat-form-field appearance="outline" class="search-field">
        <mat-label>Search libraries...</mat-label>
        <input matInput [ngModel]="searchText()" (ngModelChange)="searchText.set($event)" placeholder="Filter across all tabs" />
        <mat-icon matSuffix>search</mat-icon>
      </mat-form-field>

      <mat-tab-group animationDuration="200ms">
        @for (project of projects; track project.id) {
          <mat-tab [label]="project.title">
            <div class="tab-content">
              @if (filteredLibraries(project).length === 0) {
                <p class="no-results">No libraries match your search.</p>
              } @else {
                <table mat-table [dataSource]="filteredLibraries(project)" class="mat-elevation-z2 lib-table">
                  <ng-container matColumnDef="concern">
                    <th mat-header-cell *matHeaderCellDef>Concern</th>
                    <td mat-cell *matCellDef="let lib">
                      {{ lib.concern }}
                      @if (lib.isNew) {
                        <span class="new-badge">🆕</span>
                      }
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="mustHave">
                    <th mat-header-cell *matHeaderCellDef>Must-Have</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.mustHave }}</td>
                  </ng-container>

                  <ng-container matColumnDef="alternatives">
                    <th mat-header-cell *matHeaderCellDef>Alternatives</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.alternatives }}</td>
                  </ng-container>

                  <ng-container matColumnDef="notes">
                    <th mat-header-cell *matHeaderCellDef>Notes</th>
                    <td mat-cell *matCellDef="let lib">{{ lib.notes }}</td>
                  </ng-container>

                  <ng-container matColumnDef="license">
                    <th mat-header-cell *matHeaderCellDef>License</th>
                    <td mat-cell *matCellDef="let lib">
                      <mat-chip-set>
                        <mat-chip [class]="'license-' + lib.license" highlighted>
                          {{ lib.license | uppercase }}
                        </mat-chip>
                      </mat-chip-set>
                    </td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="libColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: libColumns;"></tr>
                </table>
              }

              @if (project.title === 'Aspire') {
                <h3 class="subsection-title">Aspire Decision Matrix</h3>
                <table mat-table [dataSource]="aspireScenarios" class="mat-elevation-z2 lib-table">
                  <ng-container matColumnDef="scenario">
                    <th mat-header-cell *matHeaderCellDef>Scenario</th>
                    <td mat-cell *matCellDef="let s">{{ s.scenario }}</td>
                  </ng-container>

                  <ng-container matColumnDef="useAspire">
                    <th mat-header-cell *matHeaderCellDef>Use Aspire?</th>
                    <td mat-cell *matCellDef="let s">
                      <span class="aspire-decision">{{ s.useAspire ? '✅' : '❌' }}</span>
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="enforcement">
                    <th mat-header-cell *matHeaderCellDef>Enforcement</th>
                    <td mat-cell *matCellDef="let s">
                      <app-enforcement-badge [level]="s.enforcement" />
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="notes">
                    <th mat-header-cell *matHeaderCellDef>Notes</th>
                    <td mat-cell *matCellDef="let s">{{ s.notes }}</td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="aspireColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: aspireColumns;"></tr>
                </table>

                <h3 class="subsection-title">Aspire Anti-Patterns</h3>
                <div class="anti-patterns-grid">
                  @for (ap of aspireAntiPatterns; track ap.antiPattern) {
                    <mat-card class="anti-pattern-card">
                      <mat-card-header>
                        <mat-card-title>{{ ap.antiPattern }}</mat-card-title>
                      </mat-card-header>
                      <mat-card-content>
                        <p><strong>Risk:</strong> {{ ap.risk }}</p>
                        <p><strong>Correct Approach:</strong> {{ ap.correctApproach }}</p>
                      </mat-card-content>
                    </mat-card>
                  }
                </div>
              }
            </div>
          </mat-tab>
        }
      </mat-tab-group>
    </section>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }

    h2 {
      margin-bottom: 20px;
      font-weight: 500;
    }

    .search-field {
      width: 100%;
      max-width: 480px;
      margin-bottom: 16px;
    }

    .tab-content {
      padding: 16px 0;
    }

    .lib-table {
      width: 100%;
      margin-bottom: 24px;
    }

    .new-badge {
      margin-left: 6px;
      font-size: 14px;
    }

    .no-results {
      padding: 24px;
      text-align: center;
      color: rgba(0, 0, 0, 0.54);
    }

    .subsection-title {
      margin: 32px 0 16px;
      font-weight: 500;
      font-size: 1.2em;
    }

    .aspire-decision {
      font-size: 1.3em;
    }

    .anti-patterns-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
      gap: 16px;
      margin-top: 8px;
    }

    .anti-pattern-card {
      mat-card-content p {
        margin: 8px 0;
      }
    }

    .license-oss {
      --mdc-chip-elevated-container-color: #c8e6c9;
      --mdc-chip-label-text-color: #2e7d32;
    }

    .license-commercial {
      --mdc-chip-elevated-container-color: #ffcdd2;
      --mdc-chip-label-text-color: #c62828;
    }

    .license-mixed {
      --mdc-chip-elevated-container-color: #fff8e1;
      --mdc-chip-label-text-color: #f57f17;
    }

    td.mat-mdc-cell, th.mat-mdc-header-cell {
      padding: 12px 16px;
    }
  `],
})
export class ProjectLibrariesPage {
  readonly projects = PROJECT_SPECIFIC_LIBS;
  readonly aspireScenarios = ASPIRE_SCENARIOS;
  readonly aspireAntiPatterns = ASPIRE_ANTI_PATTERNS;
  readonly libColumns = ['concern', 'mustHave', 'alternatives', 'notes', 'license'];
  readonly aspireColumns = ['scenario', 'useAspire', 'enforcement', 'notes'];
  readonly searchText = signal('');

  filteredLibraries(project: ProjectSpecificLib): LibraryEntry[] {
    const term = this.searchText().toLowerCase().trim();
    if (!term) return project.libraries;
    return project.libraries.filter(
      (lib) =>
        lib.concern.toLowerCase().includes(term) ||
        lib.mustHave.toLowerCase().includes(term) ||
        lib.alternatives.toLowerCase().includes(term) ||
        lib.notes.toLowerCase().includes(term) ||
        lib.license.toLowerCase().includes(term)
    );
  }
}
