import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { ANTI_PATTERNS } from '../../data/standards-data';

@Component({
  selector: 'app-anti-patterns',
  standalone: true,
  imports: [MatCardModule],
  template: `
    <h2 class="page-title">4. Anti-Patterns &amp; Corrections</h2>
    <div class="grid">
      @for (item of antiPatterns; track item.pattern) {
        <mat-card class="pattern-card">
          <mat-card-header>
            <mat-card-title class="pattern-name">{{ item.pattern }}</mat-card-title>
          </mat-card-header>
          <mat-card-content>
            <div class="section">
              <span class="label problem-label">Problem</span>
              <p>{{ item.problem }}</p>
            </div>
            <div class="section">
              <span class="label do-label">Do Instead</span>
              <p>{{ item.doInstead }}</p>
            </div>
          </mat-card-content>
        </mat-card>
      }
    </div>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(420px, 1fr));
      gap: 20px;
    }
    .pattern-card {
      border-top: 4px solid #ef5350;
    }
    .pattern-name {
      color: #c62828;
      font-size: 16px;
    }
    .section {
      margin-top: 12px;
    }
    .label {
      display: inline-block;
      font-weight: 600;
      font-size: 13px;
      padding: 2px 10px;
      border-radius: 4px;
      margin-bottom: 4px;
    }
    .problem-label {
      background-color: #ffcdd2;
      color: #b71c1c;
    }
    .do-label {
      background-color: #c8e6c9;
      color: #1b5e20;
    }
    p {
      margin: 4px 0 0;
      line-height: 1.5;
    }
  `]
})
export class AntiPatternsPage {
  readonly antiPatterns = ANTI_PATTERNS;
}
