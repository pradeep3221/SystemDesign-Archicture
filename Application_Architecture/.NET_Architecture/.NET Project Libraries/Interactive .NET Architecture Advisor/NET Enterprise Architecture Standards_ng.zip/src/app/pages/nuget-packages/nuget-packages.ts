import { Component } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { CodeBlock } from '../../shared/code-block';
import { CopyClipboard } from '../../shared/copy-clipboard';
import { NUGET_GROUPS, NugetGroup } from '../../data/standards-data';

@Component({
  selector: 'app-nuget-packages',
  standalone: true,
  imports: [MatTabsModule, CodeBlock, CopyClipboard],
  template: `
    <section class="page-container">
      <h2>10. Essential NuGet Package Groups</h2>

      <mat-tab-group animationDuration="200ms">
        @for (group of groups; track group.id) {
          <mat-tab [label]="group.title">
            <div class="tab-content">
              <div class="code-actions">
                <app-copy-clipboard [text]="group.xml" />
              </div>
              <app-code-block
                [code]="group.xml"
                [title]="'Directory.Packages.props — ' + group.title"
              />
            </div>
          </mat-tab>
        }
      </mat-tab-group>
    </section>
  `,
  styles: [`
    .page-container {
      padding: 24px;
      max-width: 1400px;
      margin: 0 auto;
    }

    h2 {
      margin-bottom: 20px;
      font-weight: 500;
    }

    .tab-content {
      padding: 16px 0;
    }

    .code-actions {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 8px;
    }
  `],
})
export class NugetPackagesPage {
  readonly groups: NugetGroup[] = NUGET_GROUPS;
}
