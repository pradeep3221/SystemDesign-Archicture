import { Component, computed } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import { EnforcementIconPipe } from '../../shared/enforcement-icon.pipe';
import {
  ENFORCEMENT_LEVELS,
  AI_OPS_CONTROLS,
  type AiOpsControl,
} from '../../data/standards-data';

interface GroupedRow {
  isGroupHeader: boolean;
  category: string;
  control: string;
  implementation: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
}

@Component({
  selector: 'app-enforcement',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    EnforcementBadge,
    EnforcementIconPipe,
  ],
  template: `
    <h2 class="page-title">Enforcement Model</h2>

    <h3 class="section-title">Enforcement Levels</h3>
    <div class="levels-grid">
      @for (level of enforcementLevels; track level.level) {
        <mat-card class="level-card" [class]="'level-' + level.level">
          <mat-card-content>
            <div class="level-icon">{{ level.icon }}</div>
            <div class="level-name">{{ level.level }}</div>
            <p class="level-meaning">{{ level.meaning }}</p>
            <div class="level-examples">
              <strong>Examples:</strong> {{ level.examples }}
            </div>
          </mat-card-content>
        </mat-card>
      }
    </div>

    <h3 class="section-title">AI Operational Controls</h3>
    <mat-card class="section-card">
      <mat-card-content>
        <table mat-table [dataSource]="groupedControls" class="full-width">
          <ng-container matColumnDef="control">
            <th mat-header-cell *matHeaderCellDef>Control</th>
            <td mat-cell *matCellDef="let row">{{ row.control }}</td>
          </ng-container>

          <ng-container matColumnDef="implementation">
            <th mat-header-cell *matHeaderCellDef>Implementation</th>
            <td mat-cell *matCellDef="let row">{{ row.implementation }}</td>
          </ng-container>

          <ng-container matColumnDef="enforcement">
            <th mat-header-cell *matHeaderCellDef>Enforcement</th>
            <td mat-cell *matCellDef="let row">
              <app-enforcement-badge
                [level]="row.enforcement"
                [icon]="row.enforcement | enforcementIcon"
              />
            </td>
          </ng-container>

          <ng-container matColumnDef="groupHeader">
            <td mat-cell *matCellDef="let row" [attr.colspan]="controlColumns.length">
              <strong class="group-header">{{ row.category }}</strong>
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="controlColumns"></tr>
          <tr
            mat-row
            *matRowDef="let row; columns: controlColumns; when: isDataRow"
          ></tr>
          <tr
            mat-row
            *matRowDef="let row; columns: ['groupHeader']; when: isGroupRow"
            class="group-row"
          ></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-title {
      margin: 24px 0 16px;
      font-weight: 500;
    }
    .section-card {
      margin-bottom: 24px;
    }
    .full-width {
      width: 100%;
    }
    .levels-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .level-card {
      text-align: center;
    }
    .level-MUST {
      background: #fde8e8;
    }
    .level-SHOULD {
      background: #fff3e0;
    }
    .level-MAY {
      background: #e8f5e9;
    }
    .level-icon {
      font-size: 40px;
      margin-bottom: 8px;
    }
    .level-name {
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 8px;
    }
    .level-meaning {
      color: rgba(0, 0, 0, 0.7);
      margin-bottom: 12px;
    }
    .level-examples {
      font-size: 13px;
      text-align: left;
    }
    .group-row {
      background: #f5f5f5;
    }
    .group-header {
      font-size: 14px;
      padding: 4px 0;
    }
  `],
})
export class EnforcementPage {
  readonly enforcementLevels = ENFORCEMENT_LEVELS;
  readonly controlColumns = ['control', 'implementation', 'enforcement'];

  readonly groupedControls = this.buildGroupedRows(AI_OPS_CONTROLS);

  isGroupRow = (_index: number, row: GroupedRow) => row.isGroupHeader;
  isDataRow = (_index: number, row: GroupedRow) => !row.isGroupHeader;

  private buildGroupedRows(controls: AiOpsControl[]): GroupedRow[] {
    const rows: GroupedRow[] = [];
    let currentCategory = '';

    for (const c of controls) {
      if (c.category !== currentCategory) {
        currentCategory = c.category;
        rows.push({
          isGroupHeader: true,
          category: c.category,
          control: '',
          implementation: '',
          enforcement: 'MUST',
        });
      }
      rows.push({
        isGroupHeader: false,
        category: c.category,
        control: c.control,
        implementation: c.implementation,
        enforcement: c.enforcement,
      });
    }

    return rows;
  }
}
