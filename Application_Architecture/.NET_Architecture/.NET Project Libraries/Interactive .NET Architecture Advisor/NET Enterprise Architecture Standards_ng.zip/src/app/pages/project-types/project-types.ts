import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { PROJECT_TYPES } from '../../data/standards-data';

@Component({
  selector: 'app-project-types',
  standalone: true,
  imports: [MatCardModule, MatTableModule],
  template: `
    <h2 class="page-title">1. Project Types</h2>
    <mat-card>
      <mat-card-content>
        <table mat-table [dataSource]="dataSource" class="full-width">
          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Name</th>
            <td mat-cell *matCellDef="let row">{{ row.name }}</td>
          </ng-container>

          <ng-container matColumnDef="category">
            <th mat-header-cell *matHeaderCellDef>Category</th>
            <td mat-cell *matCellDef="let row">{{ row.category }}</td>
          </ng-container>

          <ng-container matColumnDef="architecture">
            <th mat-header-cell *matHeaderCellDef>Architecture</th>
            <td mat-cell *matCellDef="let row">{{ row.architecture }}</td>
          </ng-container>

          <ng-container matColumnDef="examples">
            <th mat-header-cell *matHeaderCellDef>Examples</th>
            <td mat-cell *matCellDef="let row">{{ row.examples }}</td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .full-width {
      width: 100%;
    }
    mat-card {
      margin-bottom: 24px;
    }
  `]
})
export class ProjectTypesPage {
  readonly dataSource = PROJECT_TYPES;
  readonly displayedColumns = ['name', 'category', 'architecture', 'examples'];
}
