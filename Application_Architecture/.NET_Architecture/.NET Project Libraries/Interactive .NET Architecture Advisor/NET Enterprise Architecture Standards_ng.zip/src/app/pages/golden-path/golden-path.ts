import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { EnforcementBadge } from '../../shared/enforcement-badge';
import { EnforcementIconPipe } from '../../shared/enforcement-icon.pipe';
import {
  TEMPLATE_REQUIREMENTS,
  COMPONENT_WIRING,
} from '../../data/standards-data';

@Component({
  selector: 'app-golden-path',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    MatIconModule,
    EnforcementBadge,
    EnforcementIconPipe,
  ],
  template: `
    <h2 class="page-title">13. Golden Path — Starter Template</h2>

    <mat-card class="section-card">
      <mat-card-header>
        <mat-card-title>Template Requirements</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="templateRequirements" class="full-width">
          <ng-container matColumnDef="concern">
            <th mat-header-cell *matHeaderCellDef>Concern</th>
            <td mat-cell *matCellDef="let row">{{ row.concern }}</td>
          </ng-container>

          <ng-container matColumnDef="preWired">
            <th mat-header-cell *matHeaderCellDef>Pre-Wired Implementation</th>
            <td mat-cell *matCellDef="let row">{{ row.preWired }}</td>
          </ng-container>

          <ng-container matColumnDef="enforcement">
            <th mat-header-cell *matHeaderCellDef>Enforcement</th>
            <td mat-cell *matCellDef="let row">
              <app-enforcement-badge
                [level]="row.enforcement"
                [icon]="row.enforcement | enforcementIcon"
              />
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="templateColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: templateColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>

    <mat-card class="section-card">
      <mat-card-header>
        <mat-card-title>Component Wiring</mat-card-title>
      </mat-card-header>
      <mat-card-content>
        <table mat-table [dataSource]="componentWiring" class="full-width">
          <ng-container matColumnDef="component">
            <th mat-header-cell *matHeaderCellDef>Component</th>
            <td mat-cell *matCellDef="let row">{{ row.component }}</td>
          </ng-container>

          <ng-container matColumnDef="technology">
            <th mat-header-cell *matHeaderCellDef>Technology</th>
            <td mat-cell *matCellDef="let row">{{ row.technology }}</td>
          </ng-container>

          <ng-container matColumnDef="enforcement">
            <th mat-header-cell *matHeaderCellDef>Enforcement</th>
            <td mat-cell *matCellDef="let row">
              <app-enforcement-badge
                [level]="row.enforcement"
                [icon]="row.enforcement | enforcementIcon"
              />
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="wiringColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: wiringColumns"></tr>
        </table>
      </mat-card-content>
    </mat-card>

    <div class="callout-warning">
      <mat-icon>warning</mat-icon>
      <div>
        <strong>Anti-Pattern Warning</strong>
        <p>
          Creating a service from <code>dotnet new webapi</code> and manually
          adding packages guarantees inconsistency across teams.
        </p>
      </div>
    </div>
  `,
  styles: [`
    .page-title {
      margin-bottom: 16px;
      font-weight: 500;
    }
    .section-card {
      margin-bottom: 24px;
    }
    .full-width {
      width: 100%;
    }
    .callout-warning {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 16px 20px;
      background: #fff3e0;
      border-left: 4px solid #ff9800;
      border-radius: 4px;
      margin-top: 8px;
    }
    .callout-warning mat-icon {
      color: #e65100;
      margin-top: 2px;
    }
    .callout-warning p {
      margin: 4px 0 0;
      color: rgba(0, 0, 0, 0.7);
    }
    .callout-warning code {
      background: rgba(0, 0, 0, 0.08);
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 13px;
    }
  `],
})
export class GoldenPathPage {
  readonly templateRequirements = TEMPLATE_REQUIREMENTS;
  readonly componentWiring = COMPONENT_WIRING;

  readonly templateColumns = ['concern', 'preWired', 'enforcement'];
  readonly wiringColumns = ['component', 'technology', 'enforcement'];
}
