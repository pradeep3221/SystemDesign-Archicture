import { Routes } from '@angular/router';
import { SECTION_REGISTRY } from './data/section-registry';

// Routes are auto-generated from the section registry.
// To add a new section, update SECTION_REGISTRY — no need to touch this file.
export const routes: Routes = [
  { path: '', redirectTo: 'default-stack', pathMatch: 'full' },
  ...SECTION_REGISTRY.map(entry => ({
    path: entry.nav.id,
    loadComponent: entry.loadComponent,
  })),
  { path: '**', redirectTo: 'default-stack' },
];
