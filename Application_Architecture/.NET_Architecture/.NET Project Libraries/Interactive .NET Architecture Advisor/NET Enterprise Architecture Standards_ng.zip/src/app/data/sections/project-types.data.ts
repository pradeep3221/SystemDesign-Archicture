import { ProjectType } from '../interfaces';

export const PROJECT_TYPES: ProjectType[] = [
  {
    name: 'Web API / Microservice',
    category: 'Backend',
    architecture: 'Clean Architecture + CQRS',
    examples: 'REST/gRPC service, domain-driven bounded context',
  },
  {
    name: 'Blazor Web App (Unified)',
    category: 'Full-stack Web',
    architecture: 'Component-based + optional Clean Arch backend',
    examples: 'Internal LOB tools, dashboards, portals',
  },
  {
    name: 'Worker Service / Background Jobs',
    category: 'Backend',
    architecture: 'Pipeline / Queue consumer',
    examples: 'Message processors, scheduled tasks, ETL',
  },
  {
    name: 'gRPC Service',
    category: 'Backend',
    architecture: 'Contract-first + Clean Architecture',
    examples: 'Inter-service communication, high-throughput RPCs',
  },
  {
    name: 'WPF / WinForms Desktop',
    category: 'Desktop',
    architecture: 'MVVM (WPF) / MVP (WinForms)',
    examples: 'Thick-client enterprise tools, legacy modernization',
  },
  {
    name: 'Azure Functions (Isolated)',
    category: 'Serverless',
    architecture: 'Function-per-use-case, optional Clean Arch',
    examples: 'Event-driven processing, lightweight APIs',
  },
  {
    name: 'MAUI (Cross-Platform)',
    category: 'Mobile/Desktop',
    architecture: 'MVVM + Shell navigation',
    examples: 'Field apps, companion mobile apps',
  },
];
