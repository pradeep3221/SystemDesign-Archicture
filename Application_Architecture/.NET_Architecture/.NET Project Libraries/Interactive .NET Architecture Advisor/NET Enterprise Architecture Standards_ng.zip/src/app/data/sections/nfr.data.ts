import { NfrSection, ServiceTier } from '../interfaces';

export const NFR_SECTIONS: NfrSection[] = [
  {
    id: 'performance',
    title: 'Performance',
    metrics: [
      { metric: 'API Response Time (P95)', target: '< 200ms', enforcement: 'MUST', measurement: 'Application Insights / OpenTelemetry histograms' },
      { metric: 'API Response Time (P99)', target: '< 500ms', enforcement: 'SHOULD', measurement: 'Application Insights / OpenTelemetry histograms' },
      { metric: 'Database Query Time (P95)', target: '< 50ms', enforcement: 'SHOULD', measurement: 'EF Core / Dapper instrumentation via OpenTelemetry' },
      { metric: 'Throughput', target: '> 1000 RPS per instance', enforcement: 'SHOULD', measurement: 'Load testing with k6, NBomber, or Azure Load Testing' },
      { metric: 'Cold Start (Serverless)', target: '< 3s', enforcement: 'SHOULD', measurement: 'Azure Functions metrics; isolated worker with trimming' },
    ],
  },
  {
    id: 'availability',
    title: 'Availability',
    metrics: [
      { metric: 'Uptime SLA', target: '99.9% (Tier 1), 99.5% (Tier 2)', enforcement: 'MUST', measurement: 'Azure Monitor availability tests; synthetic monitoring' },
      { metric: 'Health Check Response', target: '< 5s for /health, < 10s for /ready', enforcement: 'MUST', measurement: 'Kubernetes liveness/readiness probe configuration' },
      { metric: 'Failover Time (RTO)', target: '< 15 minutes (Tier 1)', enforcement: 'SHOULD', measurement: 'DR drill exercises; documented runbooks' },
      { metric: 'Data Loss Window (RPO)', target: '< 1 hour (Tier 1)', enforcement: 'SHOULD', measurement: 'Backup frequency validation; replication lag monitoring' },
    ],
  },
  {
    id: 'scalability',
    title: 'Scalability',
    metrics: [
      { metric: 'Horizontal Scale', target: 'Stateless services scale to 10+ instances', enforcement: 'MUST', measurement: 'Kubernetes HPA or Azure autoscale rules' },
      { metric: 'Connection Pooling', target: 'Configured for all DB and cache connections', enforcement: 'MUST', measurement: 'Connection pool metrics; max pool size tuning' },
      { metric: 'Message Processing', target: '> 500 messages/sec per consumer', enforcement: 'SHOULD', measurement: 'MassTransit metrics; queue depth monitoring' },
      { metric: 'Cache Hit Ratio', target: '> 80% for read-heavy paths', enforcement: 'SHOULD', measurement: 'HybridCache/Redis metrics; Application Insights custom metrics' },
    ],
  },
  {
    id: 'security',
    title: 'Security',
    metrics: [
      { metric: 'Authentication', target: 'All endpoints authenticated (unless explicitly public)', enforcement: 'MUST', measurement: 'Architecture tests; penetration testing; OWASP ZAP scans' },
      { metric: 'TLS', target: 'TLS 1.2+ for all traffic; HTTPS redirect enabled', enforcement: 'MUST', measurement: 'SSL Labs scan; Azure Policy compliance' },
      { metric: 'Secret Management', target: 'Zero secrets in code or config files', enforcement: 'MUST', measurement: 'Git secret scanning; Key Vault audit logs' },
      { metric: 'Dependency Scanning', target: 'No critical CVEs in production dependencies', enforcement: 'MUST', measurement: 'Dependabot / Snyk / NuGet audit in CI pipeline' },
      { metric: 'Input Validation', target: 'All user input validated at API boundary', enforcement: 'MUST', measurement: 'FluentValidation coverage; fuzzing tests' },
      { metric: 'OWASP Top 10', target: 'Mitigated for all applicable categories', enforcement: 'MUST', measurement: 'Annual penetration test; SAST/DAST in CI' },
    ],
  },
  {
    id: 'observability',
    title: 'Observability',
    metrics: [
      { metric: 'Structured Logging', target: 'All services emit structured JSON logs', enforcement: 'MUST', measurement: 'Log format validation in CI; Serilog configuration audit' },
      { metric: 'Distributed Tracing', target: 'All inter-service calls propagate W3C Trace Context', enforcement: 'MUST', measurement: 'Trace continuity checks in integration tests' },
      { metric: 'Metrics', target: 'RED metrics (Rate, Errors, Duration) for all services', enforcement: 'MUST', measurement: 'OpenTelemetry metrics; Grafana/App Insights dashboards' },
      { metric: 'Alerting', target: 'Alerts configured for error rate > 1%, P95 > threshold', enforcement: 'SHOULD', measurement: 'Azure Monitor alert rules; PagerDuty/Opsgenie integration' },
      { metric: 'Log Retention', target: '30 days hot, 90 days warm, 1 year cold', enforcement: 'SHOULD', measurement: 'Log Analytics workspace retention settings' },
    ],
  },
  {
    id: 'cost',
    title: 'Cost Optimization',
    metrics: [
      { metric: 'Right-sizing', target: 'No over-provisioned resources (CPU < 70% avg)', enforcement: 'SHOULD', measurement: 'Azure Advisor recommendations; monthly review' },
      { metric: 'Reserved Instances', target: 'Use RI/Savings Plans for predictable workloads', enforcement: 'SHOULD', measurement: 'Azure Cost Management commitment utilization' },
      { metric: 'Idle Resource Cleanup', target: 'No orphaned disks, IPs, or unused App Service plans', enforcement: 'MUST', measurement: 'Azure Policy; automated cleanup scripts' },
      { metric: 'Cost Tagging', target: 'All resources tagged with cost-center, environment, owner', enforcement: 'MUST', measurement: 'Azure Policy tag enforcement; cost allocation reports' },
    ],
  },
  {
    id: 'service-tiers',
    title: 'Service Tiers',
    metrics: [
      { metric: 'Tier 1 — Mission Critical', target: '99.9% uptime, < 200ms P95, 24/7 on-call', enforcement: 'MUST', measurement: 'SLA dashboards; incident response SLOs' },
      { metric: 'Tier 2 — Business Important', target: '99.5% uptime, < 500ms P95, business-hours support', enforcement: 'SHOULD', measurement: 'SLA dashboards; business-hours alerting' },
      { metric: 'Tier 3 — Internal/Dev', target: '99% uptime, best-effort performance', enforcement: 'MAY', measurement: 'Basic monitoring; team-level support' },
    ],
  },
];

export const SERVICE_TIERS: ServiceTier[] = [
  {
    tier: 'Tier 1 — Mission Critical',
    definition: 'Revenue-generating or safety-critical systems. Downtime directly impacts business operations or regulatory compliance.',
    availability: '99.9% (< 8.7 hours/year downtime)',
    performance: 'P95 < 200ms, P99 < 500ms',
    examples: 'Payment processing, waste tracking, customer-facing APIs',
  },
  {
    tier: 'Tier 2 — Business Important',
    definition: 'Internal business processes that impact productivity but have workarounds. Degradation is tolerable for short periods.',
    availability: '99.5% (< 43.8 hours/year downtime)',
    performance: 'P95 < 500ms, P99 < 1s',
    examples: 'HR systems, internal dashboards, reporting services',
  },
  {
    tier: 'Tier 3 — Internal / Development',
    definition: 'Development tools, sandboxes, and internal utilities. Best-effort availability with no formal SLA.',
    availability: '99% (< 87.6 hours/year downtime)',
    performance: 'Best effort',
    examples: 'Dev/test environments, internal tools, proof-of-concepts',
  },
];
