import { VersioningRule } from '../interfaces';

export const VERSIONING_RULES: VersioningRule[] = [
  {
    principle: 'Semantic Versioning (SemVer)',
    guidance: 'All NuGet packages and APIs follow MAJOR.MINOR.PATCH. Breaking changes increment MAJOR, new features increment MINOR, fixes increment PATCH.',
  },
  {
    principle: 'Central Package Management',
    guidance: 'Use Directory.Packages.props at solution root. All PackageReference items omit Version; it\'s declared centrally. MUST be enforced via CI.',
  },
  {
    principle: 'API Versioning from Day One',
    guidance: 'Use Asp.Versioning with URL segment strategy (/api/v1/). Never release an unversioned public API. Support N-1 for deprecation window.',
  },
  {
    principle: 'Lock File for Reproducible Builds',
    guidance: 'Enable NuGet lock files (RestorePackagesWithLockFile=true). Commit packages.lock.json. CI restores with --locked-mode.',
  },
  {
    principle: '.NET Version Adoption',
    guidance: 'Adopt LTS releases for production (e.g., .NET 8 LTS). STS releases (e.g., .NET 9) for greenfield only. Plan upgrade within 6 months of new LTS.',
  },
  {
    principle: 'Deprecation Policy',
    guidance: 'Deprecated APIs marked with [Obsolete] for 2 release cycles before removal. Communicate via changelog and API docs.',
  },
];
