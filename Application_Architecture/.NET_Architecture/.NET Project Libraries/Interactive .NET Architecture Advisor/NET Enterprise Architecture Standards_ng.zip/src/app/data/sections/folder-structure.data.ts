import { NamingConvention } from '../interfaces';

export const FOLDER_STRUCTURE = `
src/
├── CompanyName.Product.Api/                 # Presentation Layer
│   ├── Controllers/ or Endpoints/           # API endpoints
│   ├── Filters/                             # Action filters, exception filters
│   ├── Middleware/                           # Custom middleware
│   ├── Extensions/                          # Service registration extensions
│   └── Program.cs                           # Composition root
│
├── CompanyName.Product.Application/         # Application Layer
│   ├── Common/
│   │   ├── Behaviors/                       # MediatR pipeline behaviors
│   │   ├── Interfaces/                      # Port interfaces
│   │   ├── Mappings/                        # Mapperly profiles
│   │   └── Models/                          # DTOs, shared models
│   ├── Features/
│   │   └── Orders/                          # Feature folder
│   │       ├── Commands/
│   │       │   └── CreateOrder/
│   │       │       ├── CreateOrderCommand.cs
│   │       │       ├── CreateOrderCommandHandler.cs
│   │       │       └── CreateOrderCommandValidator.cs
│   │       └── Queries/
│   │           └── GetOrderById/
│   │               ├── GetOrderByIdQuery.cs
│   │               ├── GetOrderByIdQueryHandler.cs
│   │               └── OrderDto.cs
│   └── DependencyInjection.cs
│
├── CompanyName.Product.Domain/              # Domain Layer
│   ├── Entities/
│   ├── ValueObjects/
│   ├── Aggregates/
│   ├── Events/
│   ├── Enums/
│   ├── Exceptions/
│   └── Interfaces/                          # Repository interfaces
│
├── CompanyName.Product.Infrastructure/      # Infrastructure Layer
│   ├── Persistence/
│   │   ├── Configurations/                  # EF type configurations
│   │   ├── Repositories/
│   │   ├── Migrations/
│   │   └── ApplicationDbContext.cs
│   ├── Messaging/
│   ├── Caching/
│   ├── ExternalServices/
│   └── DependencyInjection.cs
│
tests/
├── CompanyName.Product.Domain.Tests/
├── CompanyName.Product.Application.Tests/
├── CompanyName.Product.Infrastructure.Tests/
├── CompanyName.Product.Api.Tests/
└── CompanyName.Product.Architecture.Tests/  # NetArchTest rules
`;

export const NAMING_CONVENTIONS: NamingConvention[] = [
  { element: 'Solution', convention: 'CompanyName.ProductName', example: 'CleanHarbors.WasteTracking', enforcement: 'MUST' },
  { element: 'Project (API)', convention: 'Solution.Api', example: 'CleanHarbors.WasteTracking.Api', enforcement: 'MUST' },
  { element: 'Project (Domain)', convention: 'Solution.Domain', example: 'CleanHarbors.WasteTracking.Domain', enforcement: 'MUST' },
  { element: 'Project (Application)', convention: 'Solution.Application', example: 'CleanHarbors.WasteTracking.Application', enforcement: 'MUST' },
  { element: 'Project (Infrastructure)', convention: 'Solution.Infrastructure', example: 'CleanHarbors.WasteTracking.Infrastructure', enforcement: 'MUST' },
  { element: 'Project (Tests)', convention: 'Solution.Layer.Tests', example: 'CleanHarbors.WasteTracking.Application.Tests', enforcement: 'MUST' },
  { element: 'Namespace', convention: 'Match folder structure', example: 'CompanyName.ProductName.Domain.Entities', enforcement: 'MUST' },
  { element: 'Interface', convention: 'IPrefix + PascalCase', example: 'IOrderRepository', enforcement: 'MUST' },
  { element: 'Class', convention: 'PascalCase, noun', example: 'OrderService, CreateOrderCommand', enforcement: 'MUST' },
  { element: 'Method', convention: 'PascalCase, verb', example: 'GetOrderAsync, ValidateInput', enforcement: 'MUST' },
  { element: 'Command/Query', convention: 'Verb + Noun + Command/Query', example: 'CreateOrderCommand, GetOrderByIdQuery', enforcement: 'SHOULD' },
  { element: 'Handler', convention: 'Command/Query + Handler', example: 'CreateOrderCommandHandler', enforcement: 'SHOULD' },
  { element: 'DTO', convention: 'Noun + Dto / Response / Request', example: 'OrderDto, CreateOrderRequest', enforcement: 'SHOULD' },
  { element: 'Configuration', convention: 'Feature + Options/Settings', example: 'CacheOptions, EmailSettings', enforcement: 'SHOULD' },
  { element: 'Constants', convention: 'PascalCase static class', example: 'ErrorCodes.NotFound', enforcement: 'SHOULD' },
];
