import { NavSection, EnforcementLevel } from '../interfaces';

export const NAV_SECTIONS: NavSection[] = [
  { id: 'project-types', title: 'Project Types', icon: 'category', sectionNumber: '1' },
  { id: 'architecture', title: 'Architecture Patterns', icon: 'architecture', sectionNumber: '2' },
  { id: 'default-stack', title: 'Default Stack', icon: 'layers', sectionNumber: '3' },
  { id: 'anti-patterns', title: 'Anti-Patterns', icon: 'block', sectionNumber: '4' },
  { id: 'clean-architecture', title: 'Clean Architecture', icon: 'account_tree', sectionNumber: '5' },
  { id: 'layer-libraries', title: 'Layer Libraries', icon: 'library_books', sectionNumber: '6' },
  { id: 'project-libraries', title: 'Project-Specific Libs', icon: 'apps', sectionNumber: '7' },
  { id: 'reference-architectures', title: 'Reference Architectures', icon: 'hub', sectionNumber: '8' },
  { id: 'oss-commercial', title: 'OSS vs Commercial', icon: 'compare', sectionNumber: '9' },
  { id: 'nuget-packages', title: 'NuGet Packages', icon: 'inventory_2', sectionNumber: '10' },
  { id: 'versioning', title: 'Versioning Strategy', icon: 'update', sectionNumber: '11' },
  { id: 'folder-structure', title: 'Folder Structure', icon: 'folder_open', sectionNumber: '12' },
  { id: 'golden-path', title: 'Golden Path Template', icon: 'star', sectionNumber: '13' },
  { id: 'nfr', title: 'Non-Functional Reqs', icon: 'speed', sectionNumber: '14' },
  { id: 'enforcement', title: 'Enforcement Model', icon: 'gavel', sectionNumber: '' },
];

export const ENFORCEMENT_LEVELS: EnforcementLevel[] = [
  {
    level: 'MUST',
    icon: '🔒',
    meaning: 'Non-negotiable. CI gates, architecture tests, or code review must enforce.',
    examples: 'Structured logging, TLS, auth on all endpoints, Central Package Management',
  },
  {
    level: 'SHOULD',
    icon: '📋',
    meaning: 'Strong recommendation. Deviation requires ADR + tech lead sign-off.',
    examples: 'Dapper for complex reads, HybridCache for read-heavy paths, Aspire for multi-service',
  },
  {
    level: 'MAY',
    icon: '💡',
    meaning: 'Team discretion. Use when it fits; no justification needed to skip.',
    examples: 'Refit over raw HttpClient, Scalar over Swagger UI, SmartEnum for enums',
  },
];
