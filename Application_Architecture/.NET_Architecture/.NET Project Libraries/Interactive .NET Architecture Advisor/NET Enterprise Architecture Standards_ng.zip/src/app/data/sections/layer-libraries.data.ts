import { SubSection } from '../interfaces';

export const LAYER_LIBRARIES: SubSection[] = [
  // -------------------------------------------------------------------------
  // 6.1 Presentation Layer
  // -------------------------------------------------------------------------
  {
    id: '6.1',
    title: 'Presentation Layer',
    libraries: [
      { layer: 'Presentation', concern: 'API Framework', mustHave: 'ASP.NET Core Minimal APIs', alternatives: 'ASP.NET Core Controllers', notes: 'Minimal APIs for new; Controllers for existing', license: 'oss' },
      { layer: 'Presentation', concern: 'API Documentation', mustHave: 'Swashbuckle (OpenAPI)', alternatives: 'Scalar, NSwag', notes: 'Scalar offers modern UI; NSwag for client gen', license: 'oss' },
      { layer: 'Presentation', concern: 'API Versioning', mustHave: 'Asp.Versioning', alternatives: 'Custom headers', notes: 'URL segment versioning preferred: /api/v1/', license: 'oss' },
      { layer: 'Presentation', concern: 'Real-time Communication', mustHave: 'SignalR', alternatives: 'WebSockets, gRPC streaming', notes: 'Built-in to ASP.NET Core; auto-fallback transports', license: 'oss' },
      { layer: 'Presentation', concern: 'Rate Limiting', mustHave: 'ASP.NET Core Rate Limiting', alternatives: 'Custom middleware', notes: 'Built-in fixed/sliding/token bucket/concurrency limiters', license: 'oss' },
      { layer: 'Presentation', concern: 'Response Compression', mustHave: 'ASP.NET Core Response Compression', alternatives: 'Reverse proxy compression', notes: 'Enable Brotli + gzip; prefer proxy-level in production', license: 'oss' },
      { layer: 'Presentation', concern: 'Output Caching', mustHave: 'ASP.NET Core Output Caching', alternatives: 'Response caching, CDN', notes: 'Server-side output caching with tag-based invalidation', license: 'oss' },
      { layer: 'Presentation', concern: 'Health Checks', mustHave: 'ASP.NET Core Health Checks', alternatives: 'Custom endpoints', notes: 'Include liveness + readiness probes for K8s/Azure', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 6.2 Application Layer
  // -------------------------------------------------------------------------
  {
    id: '6.2',
    title: 'Application Layer',
    libraries: [
      { layer: 'Application', concern: 'CQRS / Mediator', mustHave: 'MediatR', alternatives: 'Wolverine, custom dispatcher', notes: 'Pipeline behaviors for cross-cutting (logging, validation, tx)', license: 'oss' },
      { layer: 'Application', concern: 'Validation', mustHave: 'FluentValidation', alternatives: 'Data Annotations, custom', notes: 'Register as MediatR pipeline behavior for auto-validation', license: 'oss' },
      { layer: 'Application', concern: 'Object Mapping', mustHave: 'Mapperly', alternatives: 'AutoMapper, Mapster', notes: 'Source-generated; zero reflection; compile-time safety', isNew: true, license: 'oss' },
      { layer: 'Application', concern: 'Result Pattern', mustHave: 'FluentResults', alternatives: 'ErrorOr, OneOf', notes: 'Avoid exceptions for expected business failures', license: 'oss' },
      { layer: 'Application', concern: 'Date/Time', mustHave: 'NodaTime', alternatives: 'System.DateTime with UTC convention', notes: 'Strongly-typed date/time; eliminates timezone bugs', license: 'oss' },
      { layer: 'Application', concern: 'Background Jobs', mustHave: 'Hangfire / Quartz.NET', alternatives: 'Azure Functions timer triggers', notes: 'Hangfire for dashboard; Quartz for complex schedules', license: 'mixed' },
    ],
  },
  // -------------------------------------------------------------------------
  // 6.3 Domain Layer
  // -------------------------------------------------------------------------
  {
    id: '6.3',
    title: 'Domain Layer',
    libraries: [
      { layer: 'Domain', concern: 'Domain Primitives', mustHave: 'Vogen', alternatives: 'StronglyTypedId, custom value objects', notes: 'Source-generated value objects with validation; eliminates primitive obsession', isNew: true, license: 'oss' },
      { layer: 'Domain', concern: 'Smart Enums', mustHave: 'Ardalis.SmartEnum', alternatives: 'Custom enum classes', notes: 'Behavior-rich enumerations; replaces switch statements', license: 'oss' },
      { layer: 'Domain', concern: 'Guard Clauses', mustHave: 'Ardalis.GuardClauses', alternatives: 'Custom guards, ThrowHelper', notes: 'Fluent argument validation for domain invariants', license: 'oss' },
      { layer: 'Domain', concern: 'Specification Pattern', mustHave: 'Ardalis.Specification', alternatives: 'Custom specifications', notes: 'Encapsulate query logic in reusable specification objects', license: 'oss' },
      { layer: 'Domain', concern: 'Domain Events', mustHave: 'MediatR INotification', alternatives: 'Custom event dispatcher', notes: 'Raise events from aggregates; handle in application layer', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 6.4 Infrastructure — Data Access
  // -------------------------------------------------------------------------
  {
    id: '6.4',
    title: 'Infrastructure — Data Access',
    libraries: [
      { layer: 'Infrastructure', concern: 'ORM (Writes)', mustHave: 'Entity Framework Core', alternatives: 'NHibernate', notes: 'Use for aggregates, change tracking, migrations', license: 'oss' },
      { layer: 'Infrastructure', concern: 'ORM (Reads)', mustHave: 'Dapper', alternatives: 'EF Core raw SQL, ADO.NET', notes: 'For complex queries, reports, performance-critical reads', license: 'oss' },
      { layer: 'Infrastructure', concern: 'DB Migrations', mustHave: 'EF Core Migrations', alternatives: 'DbUp, FluentMigrator', notes: 'Prefer EF migrations for dev; DbUp for production pipelines', license: 'oss' },
      { layer: 'Infrastructure', concern: 'Connection Resilience', mustHave: 'EF Core Retry Strategy', alternatives: 'Polly with ADO.NET', notes: 'EnableRetryOnFailure() for SQL Server transient faults', license: 'oss' },
      { layer: 'Infrastructure', concern: 'Caching', mustHave: 'HybridCache', alternatives: 'IDistributedCache, LazyCache', notes: 'L1+L2 with stampede protection; new in .NET 9', isNew: true, license: 'oss' },
      { layer: 'Infrastructure', concern: 'Outbox Pattern', mustHave: 'MassTransit Outbox', alternatives: 'NServiceBus, custom outbox', notes: 'Transactional outbox to prevent dual-write problems', license: 'oss' },
      { layer: 'Infrastructure', concern: 'HTTP Clients', mustHave: 'IHttpClientFactory + Refit', alternatives: 'Raw HttpClient, RestSharp', notes: 'Refit for typed clients; factory manages handler lifetime', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 6.5 Cross-Cutting Concerns
  // -------------------------------------------------------------------------
  {
    id: '6.5',
    title: 'Cross-Cutting Concerns',
    libraries: [
      // Logging
      { layer: 'Cross-Cutting', concern: 'Structured Logging', mustHave: 'Serilog', alternatives: 'NLog, Microsoft.Extensions.Logging', notes: 'Serilog with enrichers for correlation IDs, user context', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Log Aggregation', mustHave: 'Seq / Application Insights', alternatives: 'ELK Stack, Grafana Loki', notes: 'Seq for dev; Application Insights for Azure production', license: 'mixed' },
      { layer: 'Cross-Cutting', concern: 'Distributed Tracing', mustHave: 'OpenTelemetry .NET', alternatives: 'Application Insights SDK', notes: 'W3C Trace Context; vendor-neutral telemetry pipeline', license: 'oss' },
      // Auth
      { layer: 'Cross-Cutting', concern: 'Authentication', mustHave: 'Microsoft.Identity.Web', alternatives: 'IdentityServer, OpenIddict', notes: 'Entra ID integration with token validation middleware', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Authorization', mustHave: 'ASP.NET Core Policy-based Auth', alternatives: 'Custom middleware', notes: 'Define policies; use [Authorize(Policy = "...")] attributes', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Secret Management', mustHave: 'Azure Key Vault', alternatives: 'HashiCorp Vault, AWS Secrets Manager', notes: 'Bind to IConfiguration via Key Vault provider', license: 'commercial' },
      { layer: 'Cross-Cutting', concern: 'Feature Flags', mustHave: 'Azure App Configuration', alternatives: 'LaunchDarkly, Unleash', notes: 'Native .NET integration; supports gradual rollouts', license: 'mixed' },
      { layer: 'Cross-Cutting', concern: 'Data Protection', mustHave: 'ASP.NET Core Data Protection', alternatives: 'Custom encryption', notes: 'Key management for cookies, tokens, and encryption at rest', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'CORS', mustHave: 'ASP.NET Core CORS Middleware', alternatives: 'Custom middleware', notes: 'Configure per-policy; avoid AllowAll in production', license: 'oss' },
      // Testing Strategy
      { layer: 'Cross-Cutting', concern: 'Unit Testing', mustHave: 'xUnit', alternatives: 'NUnit, MSTest', notes: 'xUnit is the .NET community standard; parallel by default', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Mocking', mustHave: 'NSubstitute', alternatives: 'Moq, FakeItEasy', notes: 'Clean syntax; Moq has had supply chain concerns', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Assertions', mustHave: 'FluentAssertions', alternatives: 'Shouldly, xUnit Assert', notes: 'Readable assertion syntax with detailed failure messages', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Integration Testing', mustHave: 'WebApplicationFactory + Testcontainers', alternatives: 'Respawn, custom fixtures', notes: 'Real dependencies in Docker; WebApplicationFactory for in-proc API tests', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Architecture Testing', mustHave: 'NetArchTest', alternatives: 'ArchUnitNET', notes: 'Enforce dependency rules and naming conventions in CI', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Snapshot Testing', mustHave: 'Verify', alternatives: 'ApprovalTests', notes: 'Assert complex objects via approved snapshots', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Test Data Generation', mustHave: 'Bogus', alternatives: 'AutoFixture, GenFu', notes: 'Realistic fake data with fluent API; deterministic seeds', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Performance Testing', mustHave: 'BenchmarkDotNet', alternatives: 'NBench', notes: 'Micro-benchmarks with statistical analysis and reports', license: 'oss' },
      // Resilience
      { layer: 'Cross-Cutting', concern: 'HTTP Resilience', mustHave: 'Microsoft.Extensions.Http.Resilience', alternatives: 'Raw Polly v8', notes: 'Standard resilience handler with retry, circuit-breaker, timeout', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Resilience Pipelines', mustHave: 'Polly v8', alternatives: 'Custom retry logic', notes: 'Native .NET 8 integration; non-HTTP resilience strategies', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Circuit Breaker', mustHave: 'Polly CircuitBreaker', alternatives: 'Custom state machine', notes: 'Protect downstream services from cascading failures', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Bulkhead Isolation', mustHave: 'Polly Bulkhead / Rate Limiter', alternatives: 'SemaphoreSlim', notes: 'Limit concurrency to prevent resource exhaustion', license: 'oss' },
      // Configuration
      { layer: 'Cross-Cutting', concern: 'Configuration Binding', mustHave: 'Options<T> Pattern', alternatives: 'Raw IConfiguration', notes: 'Strongly-typed; supports validation and hot-reload', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Config Validation', mustHave: 'DataAnnotations + ValidateOnStart', alternatives: 'FluentValidation for options', notes: 'Fail fast on startup if config is invalid', license: 'oss' },
      { layer: 'Cross-Cutting', concern: 'Environment Config', mustHave: 'Azure App Configuration', alternatives: 'Consul, etcd', notes: 'Centralized config with label-based environments', license: 'commercial' },
      { layer: 'Cross-Cutting', concern: 'User Secrets', mustHave: 'dotnet user-secrets', alternatives: 'Environment variables', notes: 'Never commit secrets to source control', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 6.6 AI/ML Integration
  // -------------------------------------------------------------------------
  {
    id: '6.6',
    title: 'AI/ML Integration',
    libraries: [
      { layer: 'AI/ML', concern: 'AI Abstraction', mustHave: 'Microsoft.Extensions.AI', alternatives: 'Direct SDK calls', notes: 'Unified abstraction over OpenAI, Azure OpenAI, Ollama, etc.', isNew: true, license: 'oss' },
      { layer: 'AI/ML', concern: 'Semantic AI', mustHave: 'Semantic Kernel', alternatives: 'LangChain .NET, custom orchestration', notes: 'Prompt orchestration, plugin system, planner', license: 'oss' },
      { layer: 'AI/ML', concern: 'Azure OpenAI Client', mustHave: 'Azure.AI.OpenAI', alternatives: 'OpenAI SDK with Azure endpoint', notes: 'Official Azure OpenAI SDK with AAD auth support', license: 'oss' },
      { layer: 'AI/ML', concern: 'Vector Database', mustHave: 'Azure AI Search', alternatives: 'Qdrant, Milvus, Pinecone', notes: 'RAG pattern with hybrid search (vector + keyword)', license: 'commercial' },
      { layer: 'AI/ML', concern: 'Embeddings', mustHave: 'Azure OpenAI Embeddings', alternatives: 'SentenceTransformers, Ollama embeddings', notes: 'text-embedding-ada-002 or text-embedding-3-small', license: 'commercial' },
      { layer: 'AI/ML', concern: 'ML Inference', mustHave: 'ML.NET / ONNX Runtime', alternatives: 'TorchSharp, TensorFlow.NET', notes: 'ML.NET for .NET-native models; ONNX for cross-platform', license: 'oss' },
      { layer: 'AI/ML', concern: 'Prompt Management', mustHave: 'Semantic Kernel Prompts', alternatives: 'Handlebars, custom templates', notes: 'YAML-based prompt templates with variable injection', license: 'oss' },
      { layer: 'AI/ML', concern: 'Content Safety', mustHave: 'Azure AI Content Safety', alternatives: 'Custom filters', notes: 'MUST filter all user-facing AI output for harmful content', license: 'commercial' },
      { layer: 'AI/ML', concern: 'Token Management', mustHave: 'Microsoft.ML.Tokenizers', alternatives: 'TiktokenSharp, SharpToken', notes: 'Official .NET tokenizer for accurate token counting', isNew: true, license: 'oss' },
      { layer: 'AI/ML', concern: 'AI Observability', mustHave: 'OpenTelemetry + Semantic Kernel Telemetry', alternatives: 'Custom logging', notes: 'Trace prompt/completion pairs; measure latency and token usage', license: 'oss' },
    ],
  },
];
