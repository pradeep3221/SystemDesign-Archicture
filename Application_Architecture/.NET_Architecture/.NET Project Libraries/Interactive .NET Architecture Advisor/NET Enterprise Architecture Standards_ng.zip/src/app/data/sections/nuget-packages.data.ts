import { NugetGroup } from '../interfaces';

export const NUGET_GROUPS: NugetGroup[] = [
  {
    id: 'core',
    title: 'Core Platform',
    xml: `<ItemGroup Label="Core Platform">
  <PackageVersion Include="MediatR" Version="12.*" />
  <PackageVersion Include="FluentValidation" Version="11.*" />
  <PackageVersion Include="FluentValidation.DependencyInjectionExtensions" Version="11.*" />
  <PackageVersion Include="Mapperly" Version="3.*" />
  <PackageVersion Include="FluentResults" Version="3.*" />
  <PackageVersion Include="Ardalis.GuardClauses" Version="4.*" />
  <PackageVersion Include="Ardalis.SmartEnum" Version="8.*" />
  <PackageVersion Include="Ardalis.Specification" Version="8.*" />
  <PackageVersion Include="Vogen" Version="4.*" />
</ItemGroup>`,
  },
  {
    id: 'data',
    title: 'Data Access',
    xml: `<ItemGroup Label="Data Access">
  <PackageVersion Include="Microsoft.EntityFrameworkCore" Version="9.*" />
  <PackageVersion Include="Microsoft.EntityFrameworkCore.SqlServer" Version="9.*" />
  <PackageVersion Include="Microsoft.EntityFrameworkCore.Tools" Version="9.*" />
  <PackageVersion Include="Npgsql.EntityFrameworkCore.PostgreSQL" Version="9.*" />
  <PackageVersion Include="Dapper" Version="2.*" />
  <PackageVersion Include="Microsoft.Extensions.Caching.Hybrid" Version="9.*" />
  <PackageVersion Include="Microsoft.Extensions.Caching.StackExchangeRedis" Version="9.*" />
</ItemGroup>`,
  },
  {
    id: 'messaging',
    title: 'Messaging & Integration',
    xml: `<ItemGroup Label="Messaging &amp; Integration">
  <PackageVersion Include="MassTransit" Version="8.*" />
  <PackageVersion Include="MassTransit.RabbitMQ" Version="8.*" />
  <PackageVersion Include="MassTransit.Azure.ServiceBus.Core" Version="8.*" />
  <PackageVersion Include="MassTransit.EntityFrameworkCore" Version="8.*" />
  <PackageVersion Include="Refit" Version="7.*" />
  <PackageVersion Include="Refit.HttpClientFactory" Version="7.*" />
  <PackageVersion Include="Microsoft.Extensions.Http.Resilience" Version="9.*" />
</ItemGroup>`,
  },
  {
    id: 'observability',
    title: 'Observability',
    xml: `<ItemGroup Label="Observability">
  <PackageVersion Include="Serilog" Version="4.*" />
  <PackageVersion Include="Serilog.AspNetCore" Version="8.*" />
  <PackageVersion Include="Serilog.Sinks.Seq" Version="8.*" />
  <PackageVersion Include="Serilog.Sinks.ApplicationInsights" Version="4.*" />
  <PackageVersion Include="OpenTelemetry" Version="1.*" />
  <PackageVersion Include="OpenTelemetry.Extensions.Hosting" Version="1.*" />
  <PackageVersion Include="OpenTelemetry.Instrumentation.AspNetCore" Version="1.*" />
  <PackageVersion Include="OpenTelemetry.Instrumentation.Http" Version="1.*" />
  <PackageVersion Include="OpenTelemetry.Exporter.OpenTelemetryProtocol" Version="1.*" />
</ItemGroup>`,
  },
  {
    id: 'testing',
    title: 'Testing',
    xml: `<ItemGroup Label="Testing">
  <PackageVersion Include="xunit" Version="2.*" />
  <PackageVersion Include="xunit.runner.visualstudio" Version="2.*" />
  <PackageVersion Include="NSubstitute" Version="5.*" />
  <PackageVersion Include="FluentAssertions" Version="7.*" />
  <PackageVersion Include="Bogus" Version="35.*" />
  <PackageVersion Include="Verify.Xunit" Version="26.*" />
  <PackageVersion Include="NetArchTest.Rules" Version="1.*" />
  <PackageVersion Include="Testcontainers" Version="3.*" />
  <PackageVersion Include="Microsoft.AspNetCore.Mvc.Testing" Version="9.*" />
  <PackageVersion Include="BenchmarkDotNet" Version="0.*" />
</ItemGroup>`,
  },
];
