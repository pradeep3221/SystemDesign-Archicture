import { ProjectSpecificLib, AspireScenario, AspireAntiPattern } from '../interfaces';

export const PROJECT_SPECIFIC_LIBS: ProjectSpecificLib[] = [
  // -------------------------------------------------------------------------
  // 7.1 Blazor
  // -------------------------------------------------------------------------
  {
    id: '7.1',
    title: 'Blazor',
    libraries: [
      { layer: 'Blazor', concern: 'Component Library', mustHave: 'MudBlazor', alternatives: 'Radzen, Syncfusion Blazor', notes: 'Material Design components; rich data grid, forms, navigation', license: 'oss' },
      { layer: 'Blazor', concern: 'State Management', mustHave: 'Fluxor', alternatives: 'Blazor-State, custom cascading', notes: 'Redux pattern for Blazor; time-travel debugging', license: 'oss' },
      { layer: 'Blazor', concern: 'Authentication UI', mustHave: 'Microsoft.Authentication.WebAssembly.Msal', alternatives: 'Custom auth flow', notes: 'MSAL.js wrapper for Blazor WASM; works with Entra ID', license: 'oss' },
      { layer: 'Blazor', concern: 'Forms & Validation', mustHave: 'Built-in EditForm + FluentValidation', alternatives: 'Blazored.FluentValidation', notes: 'Integrate FluentValidation with Blazor EditForm', license: 'oss' },
      { layer: 'Blazor', concern: 'Lazy Loading', mustHave: 'Blazor Lazy Assembly Loading', alternatives: 'Custom chunking', notes: 'Load assemblies on-demand for large WASM apps', license: 'oss' },
      { layer: 'Blazor', concern: 'Virtualization', mustHave: 'Blazor Virtualize component', alternatives: 'Custom virtual scroll', notes: 'Built-in; renders only visible items for large lists', license: 'oss' },
      { layer: 'Blazor', concern: 'JS Interop', mustHave: 'IJSRuntime / [JSImport]', alternatives: 'Blazored.LocalStorage', notes: '[JSImport]/[JSExport] for AOT-compatible interop', license: 'oss' },
      { layer: 'Blazor', concern: 'Error Boundaries', mustHave: 'ErrorBoundary component', alternatives: 'Custom error handling', notes: 'Catch and display component-level errors gracefully', license: 'oss' },
      { layer: 'Blazor', concern: 'Render Modes', mustHave: 'SSR + Interactive (Unified)', alternatives: 'WASM-only, Server-only', notes: '.NET 8+ unified model; per-component render mode', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.2 Worker Service
  // -------------------------------------------------------------------------
  {
    id: '7.2',
    title: 'Worker Service',
    libraries: [
      { layer: 'Worker', concern: 'Host', mustHave: 'Microsoft.Extensions.Hosting', alternatives: 'Topshelf (legacy)', notes: 'Generic host for background services; supports DI, logging, config', license: 'oss' },
      { layer: 'Worker', concern: 'Message Consumer', mustHave: 'MassTransit Consumer', alternatives: 'Raw Azure SDK, NServiceBus', notes: 'MassTransit consumers with retry and error queues', license: 'oss' },
      { layer: 'Worker', concern: 'Scheduling', mustHave: 'Quartz.NET', alternatives: 'Hangfire, Cronos', notes: 'Cron-based scheduling with clustering support', license: 'oss' },
      { layer: 'Worker', concern: 'Queue Processing', mustHave: 'BackgroundService + Channel<T>', alternatives: 'TPL Dataflow', notes: 'System.Threading.Channels for in-memory producer/consumer', license: 'oss' },
      { layer: 'Worker', concern: 'Health Checks', mustHave: 'ASP.NET Core Health Checks', alternatives: 'Custom TCP listener', notes: 'Expose health endpoint even in non-HTTP workers', license: 'oss' },
      { layer: 'Worker', concern: 'Graceful Shutdown', mustHave: 'IHostApplicationLifetime', alternatives: 'CancellationToken plumbing', notes: 'Handle StopAsync properly; drain in-flight messages', license: 'oss' },
      { layer: 'Worker', concern: 'Idempotency', mustHave: 'Custom idempotency middleware', alternatives: 'MassTransit InMemoryOutbox', notes: 'Store processed message IDs to prevent duplicate processing', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.3 gRPC
  // -------------------------------------------------------------------------
  {
    id: '7.3',
    title: 'gRPC',
    libraries: [
      { layer: 'gRPC', concern: 'Server', mustHave: 'Grpc.AspNetCore', alternatives: 'protobuf-net.Grpc', notes: 'Code-first with protobuf-net.Grpc or contract-first with .proto files', license: 'oss' },
      { layer: 'gRPC', concern: 'Client Factory', mustHave: 'Grpc.Net.ClientFactory', alternatives: 'Manual GrpcChannel', notes: 'Integrates with IHttpClientFactory for handler management', license: 'oss' },
      { layer: 'gRPC', concern: 'Health Checks', mustHave: 'Grpc.HealthCheck', alternatives: 'Custom gRPC health service', notes: 'Standard gRPC health checking protocol', license: 'oss' },
      { layer: 'gRPC', concern: 'Reflection', mustHave: 'Grpc.AspNetCore.Server.Reflection', alternatives: 'None', notes: 'Enable for dev/test; consider disabling in production', license: 'oss' },
      { layer: 'gRPC', concern: 'Interceptors', mustHave: 'Custom Interceptors', alternatives: 'None', notes: 'Equivalent to middleware; use for logging, auth, metrics', license: 'oss' },
      { layer: 'gRPC', concern: 'Streaming', mustHave: 'ASP.NET Core gRPC Streaming', alternatives: 'SignalR', notes: 'Server/client/bidirectional streaming for real-time data', license: 'oss' },
      { layer: 'gRPC', concern: 'Transcoding', mustHave: 'gRPC JSON Transcoding', alternatives: 'gRPC-Gateway', notes: 'Expose gRPC as REST+JSON for browser clients', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.4 WPF / WinForms Desktop
  // -------------------------------------------------------------------------
  {
    id: '7.4',
    title: 'WPF / WinForms Desktop',
    libraries: [
      { layer: 'Desktop', concern: 'MVVM Framework', mustHave: 'CommunityToolkit.Mvvm', alternatives: 'Prism, ReactiveUI', notes: 'Source-generated MVVM; ObservableProperty, RelayCommand', license: 'oss' },
      { layer: 'Desktop', concern: 'DI Container', mustHave: 'Microsoft.Extensions.DependencyInjection', alternatives: 'Autofac, DryIoc', notes: 'Same DI as ASP.NET Core; consistency across stack', license: 'oss' },
      { layer: 'Desktop', concern: 'Navigation', mustHave: 'Custom navigation service', alternatives: 'Prism Regions, WPF Navigation', notes: 'Interface-based navigation with ViewModel-first approach', license: 'oss' },
      { layer: 'Desktop', concern: 'UI Controls', mustHave: 'WPF UI / ModernWPF', alternatives: 'Telerik, DevExpress, Syncfusion', notes: 'WPF UI for Fluent Design; commercial for data-heavy UIs', license: 'mixed' },
      { layer: 'Desktop', concern: 'Settings Storage', mustHave: 'Microsoft.Extensions.Configuration', alternatives: 'Properties.Settings, Registry', notes: 'Consistent with server-side config; JSON-based', license: 'oss' },
      { layer: 'Desktop', concern: 'Auto-Update', mustHave: 'Squirrel.Windows / MSIX', alternatives: 'ClickOnce, custom updater', notes: 'MSIX for Store/enterprise; Squirrel for classic install', license: 'oss' },
      { layer: 'Desktop', concern: 'Local Database', mustHave: 'SQLite + EF Core', alternatives: 'LiteDB, Realm', notes: 'Embedded database for offline-capable desktop apps', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.5 Azure Functions
  // -------------------------------------------------------------------------
  {
    id: '7.5',
    title: 'Azure Functions',
    libraries: [
      { layer: 'Functions', concern: 'Hosting Model', mustHave: 'Isolated Worker', alternatives: 'In-process (deprecated)', notes: '.NET 8+ requires isolated; in-process EOL announced', license: 'oss' },
      { layer: 'Functions', concern: 'DI', mustHave: 'HostBuilder + ConfigureServices', alternatives: 'None', notes: 'Same DI pattern as ASP.NET Core; register in Program.cs', license: 'oss' },
      { layer: 'Functions', concern: 'HTTP Triggers', mustHave: 'ASP.NET Core Integration', alternatives: 'Raw HttpRequestData', notes: 'Use ASP.NET Core integration for familiar middleware pipeline', license: 'oss' },
      { layer: 'Functions', concern: 'Durable Workflows', mustHave: 'Durable Functions', alternatives: 'Custom state machines, MassTransit Sagas', notes: 'Orchestrations, sub-orchestrations, eternal orchestrations', license: 'oss' },
      { layer: 'Functions', concern: 'Messaging Triggers', mustHave: 'Service Bus / Event Hub bindings', alternatives: 'Custom polling', notes: 'Built-in triggers with batch processing support', license: 'oss' },
      { layer: 'Functions', concern: 'Configuration', mustHave: 'Azure App Configuration + Key Vault', alternatives: 'local.settings.json only', notes: 'Bind to Options<T>; Key Vault references for secrets', license: 'mixed' },
      { layer: 'Functions', concern: 'OpenAPI', mustHave: 'Microsoft.Azure.Functions.Worker.Extensions.OpenApi', alternatives: 'Custom swagger gen', notes: 'Auto-generate OpenAPI docs from function signatures', license: 'oss' },
      { layer: 'Functions', concern: 'Logging', mustHave: 'Serilog + Application Insights', alternatives: 'Built-in ILogger', notes: 'Serilog sink for App Insights; structured logs', license: 'oss' },
      { layer: 'Functions', concern: 'Testing', mustHave: 'xUnit + FunctionTestHost', alternatives: 'Custom test setup', notes: 'Integration test with test host; mock triggers', license: 'oss' },
      { layer: 'Functions', concern: 'Resilience', mustHave: 'Polly v8', alternatives: 'Built-in retry policies', notes: 'Custom resilience for outbound calls; triggers have built-in retry', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.6 MAUI
  // -------------------------------------------------------------------------
  {
    id: '7.6',
    title: 'MAUI (Cross-Platform)',
    libraries: [
      { layer: 'MAUI', concern: 'MVVM Framework', mustHave: 'CommunityToolkit.Mvvm', alternatives: 'ReactiveUI, Prism.Maui', notes: 'Source-generated MVVM; same as WPF toolkit', license: 'oss' },
      { layer: 'MAUI', concern: 'UI Toolkit', mustHave: '.NET MAUI CommunityToolkit', alternatives: 'Syncfusion, Telerik MAUI', notes: 'Converters, behaviors, effects, custom views', license: 'oss' },
      { layer: 'MAUI', concern: 'Navigation', mustHave: 'Shell Navigation', alternatives: 'Prism navigation, custom', notes: 'URI-based routing with query parameters', license: 'oss' },
      { layer: 'MAUI', concern: 'HTTP Client', mustHave: 'IHttpClientFactory + Refit', alternatives: 'Raw HttpClient', notes: 'Typed clients with Refit; platform-specific handlers', license: 'oss' },
      { layer: 'MAUI', concern: 'Local Storage', mustHave: 'SQLite + EF Core', alternatives: 'LiteDB, Preferences API', notes: 'sqlite-net-pcl for simple; EF Core for relational', license: 'oss' },
      { layer: 'MAUI', concern: 'Secure Storage', mustHave: 'SecureStorage (MAUI Essentials)', alternatives: 'Custom Keychain/Keystore', notes: 'Platform-encrypted key-value store for tokens/secrets', license: 'oss' },
      { layer: 'MAUI', concern: 'Messaging', mustHave: 'WeakReferenceMessenger', alternatives: 'IMessenger (CommunityToolkit)', notes: 'Decoupled ViewModel-to-ViewModel communication', license: 'oss' },
      { layer: 'MAUI', concern: 'Platform Features', mustHave: 'MAUI Essentials', alternatives: 'Xamarin.Essentials (legacy)', notes: 'GPS, camera, sensors, connectivity, device info', license: 'oss' },
      { layer: 'MAUI', concern: 'Testing', mustHave: 'xUnit + Appium', alternatives: 'Xamarin.UITest, custom', notes: 'Unit test ViewModels; Appium for UI automation', license: 'oss' },
    ],
  },
  // -------------------------------------------------------------------------
  // 7.7 .NET Aspire
  // -------------------------------------------------------------------------
  {
    id: '7.7',
    title: '.NET Aspire',
    libraries: [
      { layer: 'Aspire', concern: 'App Host', mustHave: 'Aspire.Hosting.AppHost', alternatives: 'Docker Compose, Tye (archived)', notes: 'Orchestrates multi-service local dev environment', isNew: true, license: 'oss' },
      { layer: 'Aspire', concern: 'Service Defaults', mustHave: 'Aspire.ServiceDefaults', alternatives: 'Custom shared project', notes: 'Pre-wires OpenTelemetry, health checks, resilience, service discovery', isNew: true, license: 'oss' },
      { layer: 'Aspire', concern: 'Dashboard', mustHave: 'Aspire Dashboard', alternatives: 'Grafana, Jaeger, Seq', notes: 'Built-in dev dashboard for traces, logs, metrics', isNew: true, license: 'oss' },
      { layer: 'Aspire', concern: 'Service Discovery', mustHave: 'Aspire Service Discovery', alternatives: 'Consul, custom DNS', notes: 'Automatic service resolution via named references', isNew: true, license: 'oss' },
      { layer: 'Aspire', concern: 'PostgreSQL', mustHave: 'Aspire.Npgsql.EntityFrameworkCore', alternatives: 'Manual EF Core setup', notes: 'Pre-configured EF Core with health checks and telemetry', license: 'oss' },
      { layer: 'Aspire', concern: 'Redis', mustHave: 'Aspire.StackExchange.Redis', alternatives: 'Manual Redis setup', notes: 'Distributed cache + output cache with Aspire integration', license: 'oss' },
      { layer: 'Aspire', concern: 'RabbitMQ', mustHave: 'Aspire.RabbitMQ.Client', alternatives: 'Manual RabbitMQ setup', notes: 'Container-managed RabbitMQ for local dev', license: 'oss' },
      { layer: 'Aspire', concern: 'Azure Integration', mustHave: 'Aspire.Hosting.Azure.*', alternatives: 'Manual Azure SDK setup', notes: 'Azure Service Bus, Storage, Key Vault, Cosmos DB components', license: 'oss' },
    ],
  },
];

export const ASPIRE_SCENARIOS: AspireScenario[] = [
  { scenario: 'Multi-service solution (2+ services)', useAspire: true, enforcement: 'SHOULD', notes: 'Aspire simplifies orchestration, service discovery, and local dev for multi-service systems.' },
  { scenario: 'Single API with database', useAspire: false, enforcement: 'MAY', notes: 'Aspire adds value with health checks and telemetry but is optional for simple setups.' },
  { scenario: 'Solution with Redis, RabbitMQ, SQL', useAspire: true, enforcement: 'SHOULD', notes: 'Aspire manages container dependencies and connection strings automatically.' },
  { scenario: 'Legacy monolith modernization', useAspire: false, enforcement: 'MAY', notes: 'Introduce Aspire when extracting services; not needed for monolith itself.' },
  { scenario: 'Azure Functions project', useAspire: false, enforcement: 'MAY', notes: 'Limited Aspire support for Functions; use Azure-native tooling.' },
  { scenario: 'CI/CD pipeline', useAspire: false, enforcement: 'MUST NOT', notes: 'Aspire is for local development. Use manifests to generate deployment artifacts.' },
  { scenario: 'Desktop (WPF/MAUI) app', useAspire: false, enforcement: 'MUST NOT', notes: 'Aspire is for cloud-native services, not desktop applications.' },
];

export const ASPIRE_ANTI_PATTERNS: AspireAntiPattern[] = [
  {
    antiPattern: 'Aspire as production orchestrator',
    risk: 'Aspire AppHost is a dev-time tool. Deploying it to production creates an unsupported runtime dependency.',
    correctApproach: 'Use Aspire for local dev; generate deployment manifests (Bicep, Helm) for production.',
  },
  {
    antiPattern: 'Hardcoding connection strings despite Aspire',
    risk: 'Bypasses Aspire service discovery and connection management; breaks local-to-cloud parity.',
    correctApproach: 'Use Aspire resource references (e.g., builder.AddProject().WithReference(redis)).',
  },
  {
    antiPattern: 'Skipping ServiceDefaults project',
    risk: 'Each service configures telemetry, health checks, and resilience differently — inconsistency and duplication.',
    correctApproach: 'Always include Aspire.ServiceDefaults and call builder.AddServiceDefaults() in every service.',
  },
  {
    antiPattern: 'Using Aspire for single-service projects unnecessarily',
    risk: 'Overhead of AppHost project, additional dependencies, and complexity without multi-service benefits.',
    correctApproach: 'For single-service projects, use standard ASP.NET Core host with manual configuration.',
  },
];
