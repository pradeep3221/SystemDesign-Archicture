import { AntiPattern } from '../interfaces';

export const ANTI_PATTERNS: AntiPattern[] = [
  {
    pattern: 'Anemic Domain Model',
    problem: 'Domain entities are data bags with no behavior; all logic lives in services, leading to scattered business rules.',
    doInstead: 'Encapsulate behavior in domain entities and value objects. Use rich domain models with methods that enforce invariants.',
  },
  {
    pattern: 'God Controller',
    problem: 'Controllers contain business logic, data access, and orchestration — violating SRP and making testing impossible.',
    doInstead: 'Keep controllers thin. Delegate to MediatR handlers or application services. Controllers only map HTTP to commands/queries.',
  },
  {
    pattern: 'Service Locator',
    problem: 'Resolving dependencies via IServiceProvider inside classes hides dependencies and breaks testability.',
    doInstead: 'Use constructor injection exclusively. Register all dependencies in the DI container at composition root.',
  },
  {
    pattern: 'Leaky Abstraction',
    problem: 'Infrastructure concerns (EF DbContext, HTTP clients) leak into domain or application layers.',
    doInstead: 'Define interfaces in inner layers; implement in Infrastructure. Domain MUST NOT reference EF, Dapper, or HTTP directly.',
  },
  {
    pattern: 'Fat Entity (Kitchen Sink Entity)',
    problem: 'Single entity serves multiple bounded contexts, growing unbounded with navigation properties and conditional logic.',
    doInstead: 'Split entities per bounded context. Use separate read models for queries. Keep aggregates focused and small.',
  },
  {
    pattern: 'No Outbox Pattern',
    problem: 'Publishing events directly after DB commit — if publish fails, state and events diverge (dual-write problem).',
    doInstead: 'Use the Transactional Outbox pattern. Store events in the same DB transaction, then relay asynchronously via MassTransit.',
  },
  {
    pattern: 'Chatty Microservices',
    problem: 'Services make synchronous HTTP calls to multiple downstream services to complete a single operation, creating latency chains.',
    doInstead: 'Use async messaging for inter-service communication. Apply CQRS to maintain local read models. Embrace eventual consistency.',
  },
  {
    pattern: 'Shared Database',
    problem: 'Multiple services read/write the same database tables, creating hidden coupling and deployment dependencies.',
    doInstead: 'Each service owns its data. Share data via APIs or events. Use change data capture if legacy DB sharing is unavoidable.',
  },
  {
    pattern: 'No Architecture Tests',
    problem: 'Dependency rules and naming conventions are only documented but never enforced, leading to gradual erosion.',
    doInstead: 'Use NetArchTest or ArchUnitNET in CI to enforce layer dependencies, naming conventions, and architectural constraints.',
  },
  {
    pattern: 'Hardcoded Configuration',
    problem: 'Connection strings, API keys, and feature flags embedded in code or appsettings.json committed to source control.',
    doInstead: 'Use Azure App Configuration, Key Vault, and user secrets. Bind to strongly-typed Options<T> with validation.',
  },
  {
    pattern: 'No Health Checks',
    problem: 'Services lack health endpoints, making it impossible for orchestrators (K8s, Azure) to detect failures and route traffic.',
    doInstead: 'Implement /health and /ready endpoints using ASP.NET Core Health Checks. Include checks for DB, cache, and downstream dependencies.',
  },
];
