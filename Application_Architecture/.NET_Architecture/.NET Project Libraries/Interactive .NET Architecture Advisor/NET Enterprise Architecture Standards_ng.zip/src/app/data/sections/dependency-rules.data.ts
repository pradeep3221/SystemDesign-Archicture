import { DependencyRule } from '../interfaces';

export const DEPENDENCY_RULES: DependencyRule[] = [
  {
    rule: 'Domain → Nothing',
    description: 'Domain layer has zero outward dependencies. It defines entities, value objects, aggregates, domain events, and repository interfaces.',
  },
  {
    rule: 'Application → Domain',
    description: 'Application layer depends only on Domain. It contains use cases (commands/queries), DTOs, validators, and port interfaces.',
  },
  {
    rule: 'Infrastructure → Application + Domain',
    description: 'Infrastructure implements interfaces defined in inner layers. Contains EF DbContext, HTTP clients, messaging, file I/O, etc.',
  },
  {
    rule: 'Presentation → Application',
    description: 'Presentation (API controllers, Blazor pages) depends on Application layer only. Never bypasses to Infrastructure directly.',
  },
  {
    rule: 'No Circular Dependencies',
    description: 'Dependencies always point inward. Outer layers MUST NOT be referenced by inner layers. Enforce via architecture tests in CI.',
  },
  {
    rule: 'Composition Root in Host',
    description: 'The host project (WebAPI, Worker) wires all layers together via DI registration. This is the only place that references all projects.',
  },
];
