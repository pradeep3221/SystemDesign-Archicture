import { TemplateRequirement, ComponentWiring } from '../interfaces';

export const TEMPLATE_REQUIREMENTS: TemplateRequirement[] = [
  { concern: 'Structured Logging', preWired: 'Serilog with console + Seq sinks, enriched with correlation ID', enforcement: 'MUST' },
  { concern: 'OpenTelemetry', preWired: 'Traces + metrics exported to OTLP endpoint; ASP.NET Core + HTTP instrumentation', enforcement: 'MUST' },
  { concern: 'Health Checks', preWired: '/health (liveness) and /ready (readiness) with DB, cache, and messaging checks', enforcement: 'MUST' },
  { concern: 'Authentication', preWired: 'Microsoft.Identity.Web configured for Entra ID; JWT bearer validation', enforcement: 'MUST' },
  { concern: 'API Versioning', preWired: 'Asp.Versioning with URL segment strategy; v1 pre-configured', enforcement: 'MUST' },
  { concern: 'Central Package Management', preWired: 'Directory.Packages.props with all standard packages pinned', enforcement: 'MUST' },
  { concern: 'FluentValidation Pipeline', preWired: 'MediatR behavior that auto-validates all commands/queries', enforcement: 'MUST' },
  { concern: 'Global Exception Handling', preWired: 'ProblemDetails middleware mapping domain exceptions to RFC 7807 responses', enforcement: 'MUST' },
  { concern: 'EF Core + Dapper', preWired: 'DbContext for writes, Dapper SqlConnection for reads, both registered in DI', enforcement: 'SHOULD' },
  { concern: 'MassTransit', preWired: 'MassTransit configured with in-memory for dev, RabbitMQ for staging/prod', enforcement: 'SHOULD' },
  { concern: 'HybridCache', preWired: 'L1 in-memory + L2 Redis with stampede protection configured', enforcement: 'SHOULD' },
  { concern: 'Architecture Tests', preWired: 'NetArchTest project enforcing layer dependencies and naming', enforcement: 'MUST' },
  { concern: 'Docker Support', preWired: 'Multi-stage Dockerfile with health check; docker-compose for local dev', enforcement: 'SHOULD' },
  { concern: 'CI Pipeline', preWired: 'GitHub Actions / Azure Pipelines YAML with build, test, lint, publish stages', enforcement: 'SHOULD' },
  { concern: 'EditorConfig + Analyzers', preWired: '.editorconfig with severity rules; Roslyn analyzers enabled as warnings', enforcement: 'MUST' },
];

export const COMPONENT_WIRING: ComponentWiring[] = [
  { component: 'HTTP Framework', technology: 'ASP.NET Core Minimal APIs', enforcement: 'MUST' },
  { component: 'CQRS / Mediator', technology: 'MediatR', enforcement: 'SHOULD' },
  { component: 'Validation', technology: 'FluentValidation (MediatR Pipeline)', enforcement: 'MUST' },
  { component: 'Object Mapping', technology: 'Mapperly (source-generated)', enforcement: 'SHOULD' },
  { component: 'ORM (Writes)', technology: 'Entity Framework Core', enforcement: 'MUST' },
  { component: 'ORM (Reads)', technology: 'Dapper', enforcement: 'SHOULD' },
  { component: 'Messaging', technology: 'MassTransit + RabbitMQ / Azure Service Bus', enforcement: 'MUST' },
  { component: 'Caching', technology: 'HybridCache (L1 + L2)', enforcement: 'SHOULD' },
  { component: 'Structured Logging', technology: 'Serilog', enforcement: 'MUST' },
  { component: 'Distributed Tracing', technology: 'OpenTelemetry', enforcement: 'MUST' },
  { component: 'Resilience', technology: 'Microsoft.Extensions.Http.Resilience (Polly v8)', enforcement: 'MUST' },
  { component: 'Authentication', technology: 'Microsoft.Identity.Web (Entra ID)', enforcement: 'MUST' },
  { component: 'Architecture Tests', technology: 'NetArchTest', enforcement: 'MUST' },
];
