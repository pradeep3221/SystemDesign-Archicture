import { ReferenceArchitecture } from '../interfaces';

export const REFERENCE_ARCHITECTURES: ReferenceArchitecture[] = [
  {
    id: 'clean-api',
    title: 'Clean Architecture Web API',
    description: 'Standard layered API with CQRS, MediatR, and Clean Architecture principles. The most common pattern for domain-driven microservices.',
    diagram: `
┌─────────────────────────────────────────────┐
│                 Presentation                 │
│        (Minimal APIs / Controllers)          │
│       Swagger · Rate Limiting · Auth         │
├─────────────────────────────────────────────┤
│                 Application                  │
│     MediatR · FluentValidation · Mapperly    │
│        Commands · Queries · DTOs             │
├─────────────────────────────────────────────┤
│                   Domain                     │
│   Entities · Value Objects · Aggregates      │
│     Domain Events · Repository Interfaces    │
├─────────────────────────────────────────────┤
│               Infrastructure                 │
│   EF Core · Dapper · MassTransit · Redis     │
│  Azure Service Bus · HTTP Clients · Outbox   │
└─────────────────────────────────────────────┘`,
  },
  {
    id: 'event-driven',
    title: 'Event-Driven Microservices',
    description: 'Asynchronous messaging backbone using MassTransit with the Transactional Outbox pattern for reliable event delivery.',
    diagram: `
┌──────────┐    ┌──────────────┐    ┌──────────┐
│ Service A │───▶│  Message Bus │───▶│ Service B │
│  (API)    │    │  (RabbitMQ / │    │ (Worker)  │
│           │    │  Service Bus)│    │           │
└─────┬─────┘    └──────────────┘    └─────┬─────┘
      │                                     │
      ▼                                     ▼
┌──────────┐                         ┌──────────┐
│  DB + TX  │                         │  DB + TX  │
│  Outbox   │                         │  Outbox   │
└──────────┘                         └──────────┘
      │                                     │
      └───────────▶ Event Store ◀───────────┘`,
  },
  {
    id: 'blazor-fullstack',
    title: 'Blazor Full-Stack App',
    description: 'Unified Blazor Web App with SSR and interactive modes, backed by Clean Architecture API layer.',
    diagram: `
┌─────────────────────────────────────────────┐
│              Blazor Web App                  │
│    SSR + Interactive Server + WASM           │
│  MudBlazor · Fluxor · Auth · SignalR         │
├─────────────────────────────────────────────┤
│               API Layer                      │
│     MediatR · Validation · Mapping           │
├─────────────────────────────────────────────┤
│          Application + Domain                │
│   Use Cases · Entities · Business Rules      │
├─────────────────────────────────────────────┤
│            Infrastructure                    │
│    EF Core · Redis · External APIs           │
└─────────────────────────────────────────────┘`,
  },
  {
    id: 'aspire-multi',
    title: 'Aspire Multi-Service Solution',
    description: '.NET Aspire orchestrates local development with service discovery, shared telemetry, and container management.',
    diagram: `
┌─────────────────────────────────────────────┐
│            Aspire AppHost                    │
│     (Orchestration + Service Discovery)      │
├──────────┬──────────┬──────────┬────────────┤
│ Web API  │ Worker   │ Blazor   │ gRPC Svc   │
│ Service  │ Service  │ Frontend │            │
├──────────┴──────────┴──────────┴────────────┤
│          Aspire Service Defaults             │
│  OpenTelemetry · Health · Resilience · Logs  │
├──────────┬──────────┬──────────┬────────────┤
│ SQL      │ Redis    │ RabbitMQ │ Azure Svc  │
│ Server   │ Cache    │ Bus      │            │
└──────────┴──────────┴──────────┴────────────┘
              Aspire Dashboard
      (Traces · Logs · Metrics · Resources)`,
  },
  {
    id: 'serverless',
    title: 'Serverless Event Processing',
    description: 'Azure Functions with Durable Functions for orchestration, event-driven processing, and lightweight APIs.',
    diagram: `
┌──────────────┐     ┌──────────────────────┐
│  Event Grid  │────▶│  Azure Function       │
│  / Webhooks  │     │  (HTTP Trigger)       │
└──────────────┘     └──────────┬────────────┘
                                │
┌──────────────┐     ┌──────────▼────────────┐
│  Service Bus │────▶│  Azure Function        │
│  Queue       │     │  (SB Trigger)          │
└──────────────┘     └──────────┬────────────┘
                                │
                     ┌──────────▼────────────┐
                     │  Durable Functions     │
                     │  (Orchestration)       │
                     └──────────┬────────────┘
                                │
                     ┌──────────▼────────────┐
                     │  Output Bindings       │
                     │  (Blob, SQL, CosmosDB) │
                     └───────────────────────┘`,
  },
];
