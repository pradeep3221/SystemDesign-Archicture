import { OssCommercialRow } from '../interfaces';

export const OSS_COMMERCIAL_MATRIX: OssCommercialRow[] = [
  {
    category: 'UI Components (Web)',
    ossChoice: 'MudBlazor',
    commercialChoice: 'Telerik UI for Blazor, Syncfusion Blazor',
    chooseCommercialWhen: 'Need advanced data grid (grouping, Excel export), Gantt charts, or scheduler components',
  },
  {
    category: 'UI Components (Desktop)',
    ossChoice: 'WPF UI / ModernWPF',
    commercialChoice: 'DevExpress WPF, Telerik WPF, Syncfusion WPF',
    chooseCommercialWhen: 'Data-intensive LOB apps requiring pivot grids, rich text editors, or chart suites',
  },
  {
    category: 'Reporting',
    ossChoice: 'QuestPDF',
    commercialChoice: 'Telerik Reporting, DevExpress Reporting, SSRS',
    chooseCommercialWhen: 'Complex multi-page reports with subreports, drill-through, or end-user designer',
  },
  {
    category: 'PDF Generation',
    ossChoice: 'QuestPDF',
    commercialChoice: 'Aspose.PDF, IronPDF',
    chooseCommercialWhen: 'PDF manipulation (merge, split, redact), HTML-to-PDF conversion at scale',
  },
  {
    category: 'Excel Processing',
    ossChoice: 'ClosedXML, EPPlus (Polyform)',
    commercialChoice: 'Aspose.Cells, Syncfusion Excel',
    chooseCommercialWhen: 'Complex pivot tables, charts in Excel, or high-volume server-side generation',
  },
  {
    category: 'Scheduling / Jobs',
    ossChoice: 'Quartz.NET, Hangfire (LGPL)',
    commercialChoice: 'Hangfire Pro, Azure Logic Apps',
    chooseCommercialWhen: 'Need reliable batching, continuations, or dashboard with pro features',
  },
  {
    category: 'Logging Platform',
    ossChoice: 'Seq (free tier), ELK Stack',
    commercialChoice: 'Datadog, Splunk, Azure Monitor',
    chooseCommercialWhen: 'Enterprise scale, SLA requirements, or integrated APM/alerting',
  },
  {
    category: 'Feature Flags',
    ossChoice: 'Unleash, Flagsmith',
    commercialChoice: 'LaunchDarkly, Azure App Configuration',
    chooseCommercialWhen: 'Need targeting rules, experimentation, or audit trail for compliance',
  },
  {
    category: 'API Gateway',
    ossChoice: 'YARP, Ocelot',
    commercialChoice: 'Azure API Management, Kong Enterprise',
    chooseCommercialWhen: 'Need developer portal, monetization, or advanced policy engine',
  },
  {
    category: 'Identity Provider',
    ossChoice: 'OpenIddict, Keycloak',
    commercialChoice: 'Azure Entra ID, Auth0, Duende IdentityServer',
    chooseCommercialWhen: 'Enterprise SSO, B2C scenarios, or need commercial support / compliance certs',
  },
  {
    category: 'Search Engine',
    ossChoice: 'Elasticsearch (SSPL), Meilisearch',
    commercialChoice: 'Azure AI Search, Algolia',
    chooseCommercialWhen: 'Need semantic/vector search, managed infrastructure, or SLA-backed service',
  },
  {
    category: 'AI / ML',
    ossChoice: 'ML.NET, ONNX Runtime, Ollama',
    commercialChoice: 'Azure OpenAI, Azure AI Services',
    chooseCommercialWhen: 'Need GPT-4 class models, content safety, enterprise compliance, and SLA',
  },
];
