// =============================================================================
// Section Registry — Single Source of Truth
// =============================================================================
// To add a new section:
//   1. Create a data file in data/sections/
//   2. Add the entry below (nav + component loader)
//   3. Create the page component
// Routes and navigation are auto-generated from this registry.
// =============================================================================

import { NavSection } from './interfaces';

export interface SectionRegistryEntry {
  /** Navigation metadata */
  nav: NavSection;
  /** Lazy component loader — used by the router */
  loadComponent: () => Promise<any>;
}

export const SECTION_REGISTRY: SectionRegistryEntry[] = [
  {
    nav: { id: 'project-types', title: 'Project Types', icon: 'category', sectionNumber: '1' },
    loadComponent: () => import('../pages/project-types/project-types').then(m => m.ProjectTypesPage),
  },
  {
    nav: { id: 'architecture', title: 'Architecture Patterns', icon: 'architecture', sectionNumber: '2' },
    loadComponent: () => import('../pages/architecture/architecture').then(m => m.ArchitecturePage),
  },
  {
    nav: { id: 'default-stack', title: 'Default Stack', icon: 'layers', sectionNumber: '3' },
    loadComponent: () => import('../pages/default-stack/default-stack').then(m => m.DefaultStackPage),
  },
  {
    nav: { id: 'anti-patterns', title: 'Anti-Patterns', icon: 'block', sectionNumber: '4' },
    loadComponent: () => import('../pages/anti-patterns/anti-patterns').then(m => m.AntiPatternsPage),
  },
  {
    nav: { id: 'clean-architecture', title: 'Clean Architecture', icon: 'account_tree', sectionNumber: '5' },
    loadComponent: () => import('../pages/clean-architecture/clean-architecture').then(m => m.CleanArchitecturePage),
  },
  {
    nav: { id: 'layer-libraries', title: 'Layer Libraries', icon: 'library_books', sectionNumber: '6' },
    loadComponent: () => import('../pages/layer-libraries/layer-libraries').then(m => m.LayerLibrariesPage),
  },
  {
    nav: { id: 'project-libraries', title: 'Project-Specific Libs', icon: 'apps', sectionNumber: '7' },
    loadComponent: () => import('../pages/project-libraries/project-libraries').then(m => m.ProjectLibrariesPage),
  },
  {
    nav: { id: 'reference-architectures', title: 'Reference Architectures', icon: 'hub', sectionNumber: '8' },
    loadComponent: () => import('../pages/reference-architectures/reference-architectures').then(m => m.ReferenceArchitecturesPage),
  },
  {
    nav: { id: 'oss-commercial', title: 'OSS vs Commercial', icon: 'compare', sectionNumber: '9' },
    loadComponent: () => import('../pages/oss-commercial/oss-commercial').then(m => m.OssCommercialPage),
  },
  {
    nav: { id: 'nuget-packages', title: 'NuGet Packages', icon: 'inventory_2', sectionNumber: '10' },
    loadComponent: () => import('../pages/nuget-packages/nuget-packages').then(m => m.NugetPackagesPage),
  },
  {
    nav: { id: 'versioning', title: 'Versioning Strategy', icon: 'update', sectionNumber: '11' },
    loadComponent: () => import('../pages/versioning/versioning').then(m => m.VersioningPage),
  },
  {
    nav: { id: 'folder-structure', title: 'Folder Structure', icon: 'folder_open', sectionNumber: '12' },
    loadComponent: () => import('../pages/folder-structure/folder-structure').then(m => m.FolderStructurePage),
  },
  {
    nav: { id: 'golden-path', title: 'Golden Path Template', icon: 'star', sectionNumber: '13' },
    loadComponent: () => import('../pages/golden-path/golden-path').then(m => m.GoldenPathPage),
  },
  {
    nav: { id: 'nfr', title: 'Non-Functional Reqs', icon: 'speed', sectionNumber: '14' },
    loadComponent: () => import('../pages/nfr/nfr').then(m => m.NfrPage),
  },
  {
    nav: { id: 'enforcement', title: 'Enforcement Model', icon: 'gavel', sectionNumber: '' },
    loadComponent: () => import('../pages/enforcement/enforcement').then(m => m.EnforcementPage),
  },
];
