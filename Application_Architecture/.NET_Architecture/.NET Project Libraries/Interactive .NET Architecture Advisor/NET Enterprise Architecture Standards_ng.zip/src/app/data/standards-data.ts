// =============================================================================
// .NET Enterprise Architecture Standards — Barrel Re-export
// =============================================================================
// This file re-exports everything from per-section data files for backward
// compatibility. New code should import directly from the section files or
// use StandardsDataService.
// =============================================================================

// Interfaces (single source of truth)
export * from './interfaces';

// Section data
export { NAV_SECTIONS, ENFORCEMENT_LEVELS } from './sections/navigation.data';
export { PROJECT_TYPES } from './sections/project-types.data';
export { DEFAULT_STACK } from './sections/default-stack.data';
export { ANTI_PATTERNS } from './sections/anti-patterns.data';
export { DEPENDENCY_RULES } from './sections/dependency-rules.data';
export { LAYER_LIBRARIES } from './sections/layer-libraries.data';
export { PROJECT_SPECIFIC_LIBS, ASPIRE_SCENARIOS, ASPIRE_ANTI_PATTERNS } from './sections/project-libraries.data';
export { REFERENCE_ARCHITECTURES } from './sections/reference-architectures.data';
export { OSS_COMMERCIAL_MATRIX } from './sections/oss-commercial.data';
export { NUGET_GROUPS } from './sections/nuget-packages.data';
export { VERSIONING_RULES } from './sections/versioning.data';
export { FOLDER_STRUCTURE, NAMING_CONVENTIONS } from './sections/folder-structure.data';
export { TEMPLATE_REQUIREMENTS, COMPONENT_WIRING } from './sections/golden-path.data';
export { NFR_SECTIONS, SERVICE_TIERS } from './sections/nfr.data';
export { AI_OPS_CONTROLS } from './sections/enforcement.data';
