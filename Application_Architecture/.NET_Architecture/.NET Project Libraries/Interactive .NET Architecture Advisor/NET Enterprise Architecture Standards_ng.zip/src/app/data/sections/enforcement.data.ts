import { AiOpsControl } from '../interfaces';

export const AI_OPS_CONTROLS: AiOpsControl[] = [
  // Prompt Safety
  { category: 'Prompt Safety', control: 'Input Sanitization', implementation: 'Validate and sanitize all user inputs before sending to LLM; strip injection attempts', enforcement: 'MUST' },
  { category: 'Prompt Safety', control: 'System Prompt Protection', implementation: 'Use meta-prompts and guardrails to prevent system prompt extraction or override', enforcement: 'MUST' },
  { category: 'Prompt Safety', control: 'Output Filtering', implementation: 'Azure AI Content Safety for all user-facing AI output; block harmful content categories', enforcement: 'MUST' },
  // Data Governance
  { category: 'Data Governance', control: 'PII Detection', implementation: 'Scan inputs for PII before sending to external AI services; redact or encrypt', enforcement: 'MUST' },
  { category: 'Data Governance', control: 'Data Residency', implementation: 'Use Azure OpenAI in approved regions; ensure data does not leave compliance boundary', enforcement: 'MUST' },
  { category: 'Data Governance', control: 'Conversation Logging', implementation: 'Log prompt/completion pairs for audit; exclude PII; configurable retention', enforcement: 'SHOULD' },
  // Model Operations
  { category: 'Model Operations', control: 'Model Versioning', implementation: 'Pin model versions in configuration; test before upgrading; A/B test new models', enforcement: 'SHOULD' },
  { category: 'Model Operations', control: 'Rate Limiting', implementation: 'Implement token-based rate limiting per user/tenant; respect Azure OpenAI TPM limits', enforcement: 'MUST' },
  { category: 'Model Operations', control: 'Fallback Strategy', implementation: 'Configure fallback models (e.g., GPT-4 → GPT-3.5) with Polly circuit breaker', enforcement: 'SHOULD' },
  // Cost Management
  { category: 'Cost Management', control: 'Token Budgeting', implementation: 'Set max token limits per request and per user session; monitor with OpenTelemetry', enforcement: 'SHOULD' },
  { category: 'Cost Management', control: 'Caching AI Responses', implementation: 'Cache deterministic AI responses (embeddings, classifications) with HybridCache', enforcement: 'SHOULD' },
  { category: 'Cost Management', control: 'Cost Allocation', implementation: 'Tag AI usage by team/feature; report token consumption per cost center', enforcement: 'MAY' },
  // Observability
  { category: 'Observability', control: 'AI Telemetry', implementation: 'Emit OpenTelemetry spans for each AI call with model, tokens, latency, and status', enforcement: 'MUST' },
  { category: 'Observability', control: 'Quality Metrics', implementation: 'Track relevance scores, user feedback (thumbs up/down), and hallucination detection', enforcement: 'SHOULD' },
  { category: 'Observability', control: 'Alerting', implementation: 'Alert on error rate > 5%, latency P95 > 10s, or content safety violations', enforcement: 'SHOULD' },
];
