// =============================================================================
// .NET Enterprise Architecture Standards — Shared Interfaces
// =============================================================================

export interface ProjectType {
  name: string;
  category: string;
  architecture: string;
  examples: string;
}

export interface DefaultStackItem {
  concern: string;
  technology: string;
  notes: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
  enforcementDetail: string;
}

export interface AntiPattern {
  pattern: string;
  problem: string;
  doInstead: string;
}

export interface LibraryEntry {
  layer: string;
  concern: string;
  mustHave: string;
  alternatives: string;
  notes: string;
  isNew?: boolean;
  license: 'oss' | 'commercial' | 'mixed';
}

export interface SubSection {
  id: string;
  title: string;
  libraries: LibraryEntry[];
}

export interface ProjectSpecificLib {
  id: string;
  title: string;
  libraries: LibraryEntry[];
}

export interface OssCommercialRow {
  category: string;
  ossChoice: string;
  commercialChoice: string;
  chooseCommercialWhen: string;
}

export interface NugetGroup {
  id: string;
  title: string;
  xml: string;
}

export interface VersioningRule {
  principle: string;
  guidance: string;
}

export interface NamingConvention {
  element: string;
  convention: string;
  example: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
}

export interface DependencyRule {
  rule: string;
  description: string;
}

export interface TemplateRequirement {
  concern: string;
  preWired: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
}

export interface NfrMetric {
  metric: string;
  target: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
  measurement: string;
}

export interface NfrSection {
  id: string;
  title: string;
  metrics: NfrMetric[];
}

export interface ServiceTier {
  tier: string;
  definition: string;
  availability: string;
  performance: string;
  examples: string;
}

export interface EnforcementLevel {
  level: string;
  icon: string;
  meaning: string;
  examples: string;
}

export interface ComponentWiring {
  component: string;
  technology: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
}

export interface AspireScenario {
  scenario: string;
  useAspire: boolean;
  enforcement: string;
  notes: string;
}

export interface AspireAntiPattern {
  antiPattern: string;
  risk: string;
  correctApproach: string;
}

export interface ReferenceArchitecture {
  id: string;
  title: string;
  diagram: string;
  description: string;
}

export interface AiOpsControl {
  category: string;
  control: string;
  implementation: string;
  enforcement: 'MUST' | 'SHOULD' | 'MAY';
}

export interface NavSection {
  id: string;
  title: string;
  icon: string;
  sectionNumber: string;
}
