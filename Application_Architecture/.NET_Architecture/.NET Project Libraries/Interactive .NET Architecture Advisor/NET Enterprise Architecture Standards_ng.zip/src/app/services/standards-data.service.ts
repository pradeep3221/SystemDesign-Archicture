import { Injectable, signal, computed } from '@angular/core';
import { SECTION_REGISTRY, SectionRegistryEntry } from '../data/section-registry';

// Per-section data imports
import { PROJECT_TYPES } from '../data/sections/project-types.data';
import { DEFAULT_STACK } from '../data/sections/default-stack.data';
import { ANTI_PATTERNS } from '../data/sections/anti-patterns.data';
import { DEPENDENCY_RULES } from '../data/sections/dependency-rules.data';
import { LAYER_LIBRARIES } from '../data/sections/layer-libraries.data';
import { PROJECT_SPECIFIC_LIBS, ASPIRE_SCENARIOS, ASPIRE_ANTI_PATTERNS } from '../data/sections/project-libraries.data';
import { REFERENCE_ARCHITECTURES } from '../data/sections/reference-architectures.data';
import { OSS_COMMERCIAL_MATRIX } from '../data/sections/oss-commercial.data';
import { NUGET_GROUPS } from '../data/sections/nuget-packages.data';
import { VERSIONING_RULES } from '../data/sections/versioning.data';
import { FOLDER_STRUCTURE, NAMING_CONVENTIONS } from '../data/sections/folder-structure.data';
import { TEMPLATE_REQUIREMENTS, COMPONENT_WIRING } from '../data/sections/golden-path.data';
import { NFR_SECTIONS, SERVICE_TIERS } from '../data/sections/nfr.data';
import { AI_OPS_CONTROLS } from '../data/sections/enforcement.data';
import { ENFORCEMENT_LEVELS } from '../data/sections/navigation.data';

export interface SearchResult {
  sectionId: string;
  sectionTitle: string;
  field: string;
  value: string;
  /** Original object for context */
  context: Record<string, unknown>;
}

/**
 * Central data service for all standards data.
 *
 * Benefits:
 * - Swap to HTTP/API by changing this service (pages stay untouched)
 * - Single place for global search across all sections
 * - Testable via DI injection
 */
@Injectable({ providedIn: 'root' })
export class StandardsDataService {
  // -------------------------------------------------------------------------
  // Registry
  // -------------------------------------------------------------------------
  readonly registry: readonly SectionRegistryEntry[] = SECTION_REGISTRY;

  // -------------------------------------------------------------------------
  // Data accessors (return readonly refs — swap to HTTP observables later)
  // -------------------------------------------------------------------------
  readonly projectTypes = PROJECT_TYPES;
  readonly defaultStack = DEFAULT_STACK;
  readonly antiPatterns = ANTI_PATTERNS;
  readonly dependencyRules = DEPENDENCY_RULES;
  readonly layerLibraries = LAYER_LIBRARIES;
  readonly projectSpecificLibs = PROJECT_SPECIFIC_LIBS;
  readonly aspireScenarios = ASPIRE_SCENARIOS;
  readonly aspireAntiPatterns = ASPIRE_ANTI_PATTERNS;
  readonly referenceArchitectures = REFERENCE_ARCHITECTURES;
  readonly ossCommercialMatrix = OSS_COMMERCIAL_MATRIX;
  readonly nugetGroups = NUGET_GROUPS;
  readonly versioningRules = VERSIONING_RULES;
  readonly folderStructure = FOLDER_STRUCTURE;
  readonly namingConventions = NAMING_CONVENTIONS;
  readonly templateRequirements = TEMPLATE_REQUIREMENTS;
  readonly componentWiring = COMPONENT_WIRING;
  readonly nfrSections = NFR_SECTIONS;
  readonly serviceTiers = SERVICE_TIERS;
  readonly enforcementLevels = ENFORCEMENT_LEVELS;
  readonly aiOpsControls = AI_OPS_CONTROLS;

  // -------------------------------------------------------------------------
  // Global Search
  // -------------------------------------------------------------------------
  readonly searchQuery = signal('');

  readonly searchResults = computed<SearchResult[]>(() => {
    const q = this.searchQuery().toLowerCase().trim();
    if (!q || q.length < 2) return [];
    return this.buildSearchIndex().filter(r => r.value.toLowerCase().includes(q));
  });

  private _cachedIndex: SearchResult[] | null = null;

  private buildSearchIndex(): SearchResult[] {
    if (this._cachedIndex) return this._cachedIndex;

    const results: SearchResult[] = [];
    const add = (sectionId: string, sectionTitle: string, obj: Record<string, unknown>) => {
      for (const [key, val] of Object.entries(obj)) {
        if (typeof val === 'string' && val.length > 0) {
          results.push({ sectionId, sectionTitle, field: key, value: val, context: obj });
        }
      }
    };

    this.projectTypes.forEach(r => add('project-types', 'Project Types', r as any));
    this.defaultStack.forEach(r => add('default-stack', 'Default Stack', r as any));
    this.antiPatterns.forEach(r => add('anti-patterns', 'Anti-Patterns', r as any));
    this.dependencyRules.forEach(r => add('clean-architecture', 'Clean Architecture', r as any));
    this.layerLibraries.forEach(s => s.libraries.forEach(r => add('layer-libraries', `Layer Libraries — ${s.title}`, r as any)));
    this.projectSpecificLibs.forEach(s => s.libraries.forEach(r => add('project-libraries', `Project Libs — ${s.title}`, r as any)));
    this.referenceArchitectures.forEach(r => add('reference-architectures', 'Reference Architectures', r as any));
    this.ossCommercialMatrix.forEach(r => add('oss-commercial', 'OSS vs Commercial', r as any));
    this.nugetGroups.forEach(r => add('nuget-packages', 'NuGet Packages', r as any));
    this.versioningRules.forEach(r => add('versioning', 'Versioning Strategy', r as any));
    this.namingConventions.forEach(r => add('folder-structure', 'Folder Structure', r as any));
    this.templateRequirements.forEach(r => add('golden-path', 'Golden Path', r as any));
    this.componentWiring.forEach(r => add('golden-path', 'Golden Path', r as any));
    this.nfrSections.forEach(s => s.metrics.forEach(r => add('nfr', `NFR — ${s.title}`, r as any)));
    this.serviceTiers.forEach(r => add('nfr', 'Service Tiers', r as any));
    this.enforcementLevels.forEach(r => add('enforcement', 'Enforcement', r as any));
    this.aiOpsControls.forEach(r => add('enforcement', 'AI Ops Controls', r as any));

    this._cachedIndex = results;
    return results;
  }
}
